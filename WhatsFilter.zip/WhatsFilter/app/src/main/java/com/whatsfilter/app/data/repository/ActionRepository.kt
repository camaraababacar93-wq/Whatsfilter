package com.whatsfilter.app.data.repository

import com.whatsfilter.app.data.dao.ActionDao
import com.whatsfilter.app.data.entities.ActionEntity
import kotlinx.coroutines.flow.Flow

class ActionRepository(private val actionDao: ActionDao) {

    fun getPending(): Flow<List<ActionEntity>> = actionDao.getPending()
    fun getCompleted(): Flow<List<ActionEntity>> = actionDao.getCompleted()
    fun getByMessage(messageId: Long): Flow<List<ActionEntity>> = actionDao.getByMessage(messageId)

    suspend fun insert(action: ActionEntity): Long = actionDao.insert(action)
    suspend fun update(action: ActionEntity) = actionDao.update(action)
    suspend fun markCompleted(id: Long) = actionDao.markCompleted(id)
    suspend fun delete(id: Long) = actionDao.delete(id)
    suspend fun deleteAll() = actionDao.deleteAll()
}
