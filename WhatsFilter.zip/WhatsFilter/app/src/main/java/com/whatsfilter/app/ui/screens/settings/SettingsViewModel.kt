package com.whatsfilter.app.ui.screens.settings

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.ViewModelProvider.AndroidViewModelFactory.Companion.APPLICATION_KEY
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.whatsfilter.app.WhatsFilterApplication
import com.whatsfilter.app.data.repository.ActionRepository
import com.whatsfilter.app.data.repository.AppSettings
import com.whatsfilter.app.data.repository.MessageRepository
import com.whatsfilter.app.data.repository.SettingsRepository
import com.whatsfilter.app.domain.usecase.LoadDemoDataUseCase
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class SettingsViewModel(
    private val settingsRepository: SettingsRepository,
    private val messageRepository: MessageRepository,
    private val actionRepository: ActionRepository,
    private val loadDemoDataUseCase: LoadDemoDataUseCase
) : ViewModel() {

    val settings: StateFlow<AppSettings> = settingsRepository.settings.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = AppSettings()
    )

    fun setDarkMode(mode: String) = viewModelScope.launch { settingsRepository.setDarkMode(mode) }
    fun setNotificationsEnabled(enabled: Boolean) = viewModelScope.launch { settingsRepository.setNotificationsEnabled(enabled) }
    fun setUrgentOnlyNotifications(enabled: Boolean) = viewModelScope.launch { settingsRepository.setUrgentOnlyNotifications(enabled) }
    fun setSoundEnabled(enabled: Boolean) = viewModelScope.launch { settingsRepository.setSoundEnabled(enabled) }
    fun setVibrationEnabled(enabled: Boolean) = viewModelScope.launch { settingsRepository.setVibrationEnabled(enabled) }
    fun setLocalAIEnabled(enabled: Boolean) = viewModelScope.launch { settingsRepository.setLocalAIEnabled(enabled) }
    fun setCloudAIEnabled(enabled: Boolean) = viewModelScope.launch { settingsRepository.setCloudAIEnabled(enabled) }
    fun setLanguage(language: String) = viewModelScope.launch { settingsRepository.setLanguage(language) }
    fun setAutoClassification(enabled: Boolean) = viewModelScope.launch { settingsRepository.setAutoClassification(enabled) }
    fun setPrivacyMode(enabled: Boolean) = viewModelScope.launch { settingsRepository.setPrivacyMode(enabled) }
    fun setOnboardingCompleted(completed: Boolean) = viewModelScope.launch { settingsRepository.setOnboardingCompleted(completed) }

    fun clearAllData() {
        viewModelScope.launch {
            messageRepository.deleteAll()
            actionRepository.deleteAll()
        }
    }

    fun loadDemoData() {
        viewModelScope.launch { loadDemoDataUseCase.execute() }
    }

    companion object {
        val Factory: ViewModelProvider.Factory = viewModelFactory {
            initializer {
                val app = this[APPLICATION_KEY] as WhatsFilterApplication
                SettingsViewModel(
                    settingsRepository = app.settingsRepository,
                    messageRepository = app.messageRepository,
                    actionRepository = app.actionRepository,
                    loadDemoDataUseCase = app.loadDemoDataUseCase
                )
            }
        }
    }
}
