package com.whatsfilter.app.ui.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.whatsfilter.app.domain.detector.ActionType
import com.whatsfilter.app.domain.model.ActionItem

@Composable
fun ActionCard(
    action: ActionItem,
    onMarkCompleted: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(modifier = modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp)) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = "${action.actionType.emoji()} ${action.description}",
                style = MaterialTheme.typography.titleSmall,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )

            val schedule = listOfNotNull(action.dueDate, action.dueTime).joinToString(" à ")
            if (schedule.isNotBlank()) {
                Text(
                    text = schedule,
                    style = MaterialTheme.typography.bodySmall,
                    modifier = Modifier.padding(top = 4.dp)
                )
            }

            if (!action.completed) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 8.dp),
                    horizontalArrangement = Arrangement.End
                ) {
                    Button(onClick = onMarkCompleted) {
                        Text("Marquer terminé")
                    }
                }
            }
        }
    }
}

private fun ActionType.emoji(): String = when (this) {
    ActionType.CALL -> "📞"
    ActionType.REPLY -> "↩️"
    ActionType.SEND_DOCUMENT -> "📄"
    ActionType.MEETING -> "📅"
    ActionType.PAYMENT -> "💰"
    ActionType.REMINDER -> "⏰"
    ActionType.OTHER -> "📌"
}
