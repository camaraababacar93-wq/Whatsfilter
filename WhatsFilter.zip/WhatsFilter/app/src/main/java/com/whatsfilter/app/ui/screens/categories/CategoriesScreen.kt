package com.whatsfilter.app.ui.screens.categories

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.whatsfilter.app.domain.model.Category
import com.whatsfilter.app.ui.theme.AppSpacing

private val presetColors = listOf(
    "#E53935", "#FB8C00", "#F9A825", "#43A047", "#9E9E9E",
    "#3B5BDB", "#2E7D32", "#6A1B9A", "#455A64", "#00838F",
    "#D81B60", "#5E35B1", "#F4511E"
)

@Composable
fun CategoriesScreen(viewModel: CategoriesViewModel = viewModel(factory = CategoriesViewModel.Factory)) {
    val state by viewModel.uiState.collectAsState()
    var editingCategory by remember { mutableStateOf<Category?>(null) }
    var showCreateDialog by remember { mutableStateOf(false) }

    Scaffold(
        floatingActionButton = {
            FloatingActionButton(onClick = { showCreateDialog = true }) {
                Text("+", style = MaterialTheme.typography.headlineSmall)
            }
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
            contentPadding = PaddingValues(AppSpacing.md)
        ) {
            item {
                Text(
                    "Catégories",
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(bottom = AppSpacing.md)
                )
            }
            items(state.categories, key = { it.id }) { category ->
                CategoryRow(
                    category = category,
                    onToggle = { enabled -> viewModel.setEnabled(category.id, enabled) },
                    onEdit = { editingCategory = category },
                    onDelete = { viewModel.deleteCategory(category.id) }
                )
            }
        }
    }

    if (showCreateDialog) {
        CategoryEditDialog(
            initial = null,
            onDismiss = { showCreateDialog = false },
            onSave = { name, emoji, color, weight ->
                viewModel.saveCategory(null, name, emoji, color, weight)
                showCreateDialog = false
            }
        )
    }

    editingCategory?.let { category ->
        CategoryEditDialog(
            initial = category,
            onDismiss = { editingCategory = null },
            onSave = { name, emoji, color, weight ->
                viewModel.saveCategory(category.id, name, emoji, color, weight)
                editingCategory = null
            }
        )
    }
}

@Composable
private fun CategoryRow(
    category: Category,
    onToggle: (Boolean) -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(bottom = AppSpacing.sm),
        shape = RoundedCornerShape(12.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(20.dp)
                        .background(parseColor(category.color), CircleShape)
                )
                Text(
                    "${category.emoji} ${category.name}",
                    style = MaterialTheme.typography.titleSmall,
                    modifier = Modifier.padding(start = 10.dp)
                )
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                TextButton(onClick = onEdit) { Text("Modifier") }
                TextButton(onClick = onDelete) { Text("Supprimer") }
                Switch(checked = category.enabled, onCheckedChange = onToggle)
            }
        }
    }
}

@Composable
private fun CategoryEditDialog(
    initial: Category?,
    onDismiss: () -> Unit,
    onSave: (name: String, emoji: String, color: String, weight: Int) -> Unit
) {
    var name by remember { mutableStateOf(initial?.name ?: "") }
    var emoji by remember { mutableStateOf(initial?.emoji ?: "🏷️") }
    var color by remember { mutableStateOf(initial?.color ?: presetColors.first()) }
    var weight by remember { mutableStateOf((initial?.priorityWeight ?: 0).toFloat()) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initial == null) "Ajouter une catégorie" else "Modifier la catégorie") },
        text = {
            Column {
                OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Nom") })
                OutlinedTextField(
                    value = emoji, onValueChange = { emoji = it }, label = { Text("Emoji") },
                    modifier = Modifier.padding(top = AppSpacing.sm)
                )
                Text("Priorité : ${weight.toInt()}", modifier = Modifier.padding(top = AppSpacing.sm))
                Slider(value = weight, onValueChange = { weight = it }, valueRange = 0f..100f)
                Text("Couleur", modifier = Modifier.padding(top = AppSpacing.sm))
                Row(modifier = Modifier.padding(top = 4.dp)) {
                    presetColors.forEach { hex ->
                        Box(
                            modifier = Modifier
                                .size(28.dp)
                                .padding(2.dp)
                                .background(parseColor(hex), CircleShape)
                                .then(
                                    if (color == hex) {
                                        Modifier.border(2.dp, MaterialTheme.colorScheme.onSurface, CircleShape)
                                    } else {
                                        Modifier
                                    }
                                )
                                .clickable { color = hex }
                        )
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = { onSave(name, emoji, color, weight.toInt()) }) { Text("Enregistrer") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Annuler") }
        }
    )
}

private fun parseColor(hex: String): Color {
    return try {
        Color(android.graphics.Color.parseColor(hex))
    } catch (e: IllegalArgumentException) {
        Color.Gray
    }
}
