package com.whatsfilter.app.domain.classifier

import com.whatsfilter.app.data.entities.KeywordRuleEntity

object CategoryClassifier {

    fun classify(text: String, rules: List<KeywordRuleEntity>): Long? {
        val lower = text.lowercase()
        val scoresByCategory = mutableMapOf<Long, Int>()

        rules.forEach { rule ->
            if (rule.enabled && lower.contains(rule.keyword.lowercase())) {
                scoresByCategory[rule.categoryId] = (scoresByCategory[rule.categoryId] ?: 0) + rule.weight
            }
        }

        return scoresByCategory.maxByOrNull { it.value }?.key
    }
}
