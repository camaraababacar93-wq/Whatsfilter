package com.whatsfilter.app.domain.detector

data class DetectedDate(
    val rawText: String,
    val isNearTerm: Boolean
)

object DateDetector {

    private val relativeNearFr = listOf("aujourd'hui", "aujourdhui")
    private val relativeTomorrowFr = listOf("demain")
    private val relativeDayAfterFr = listOf("après-demain", "apres-demain")
    private val weekdaysFr = listOf("lundi", "mardi", "mercredi", "jeudi", "vendredi", "samedi", "dimanche")
    private val monthsFr = listOf(
        "janvier", "février", "fevrier", "mars", "avril", "mai", "juin",
        "juillet", "août", "aout", "septembre", "octobre", "novembre", "décembre", "decembre"
    )

    private val relativeNearEn = listOf("today")
    private val relativeTomorrowEn = listOf("tomorrow")
    private val weekdaysEn = listOf("monday", "tuesday", "wednesday", "thursday", "friday", "saturday", "sunday")

    private val relativeNearAr = listOf("اليوم")
    private val relativeTomorrowAr = listOf("غدا", "غداً")
    private val weekdaysAr = listOf("الاثنين", "الثلاثاء", "الأربعاء", "الخميس", "الجمعة", "السبت", "الأحد")

    private val numericDateRegex = Regex("""\b(0?[1-9]|[12]\d|3[01])[/\-](0?[1-9]|1[0-2])([/\-]\d{2,4})?\b""")

    fun detect(text: String): DetectedDate? {
        val lower = text.lowercase()

        relativeNearFr.forEach { if (lower.contains(it)) return DetectedDate(it, isNearTerm = true) }
        relativeNearEn.forEach { if (lower.contains(it)) return DetectedDate(it, isNearTerm = true) }
        relativeNearAr.forEach { if (text.contains(it)) return DetectedDate(it, isNearTerm = true) }

        relativeTomorrowFr.forEach { if (lower.contains(it)) return DetectedDate(it, isNearTerm = true) }
        relativeTomorrowEn.forEach { if (lower.contains(it)) return DetectedDate(it, isNearTerm = true) }
        relativeTomorrowAr.forEach { if (text.contains(it)) return DetectedDate(it, isNearTerm = true) }

        relativeDayAfterFr.forEach { if (lower.contains(it)) return DetectedDate(it, isNearTerm = true) }

        weekdaysFr.forEach { if (lower.contains(it)) return DetectedDate(it, isNearTerm = false) }
        weekdaysEn.forEach { if (lower.contains(it)) return DetectedDate(it, isNearTerm = false) }
        weekdaysAr.forEach { if (text.contains(it)) return DetectedDate(it, isNearTerm = false) }

        monthsFr.forEach { month ->
            val regex = Regex("""\b(\d{1,2})\s+$month\b""")
            regex.find(lower)?.let { return DetectedDate(it.value, isNearTerm = false) }
        }

        numericDateRegex.find(text)?.let { return DetectedDate(it.value, isNearTerm = false) }

        return null
    }
}
