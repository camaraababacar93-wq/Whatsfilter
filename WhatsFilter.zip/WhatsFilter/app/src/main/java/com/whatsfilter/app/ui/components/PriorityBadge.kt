package com.whatsfilter.app.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.whatsfilter.app.domain.model.PriorityLevel
import com.whatsfilter.app.ui.theme.PriorityColors

data class PriorityStyle(val emoji: String, val label: String, val color: Color, val container: Color)

fun PriorityLevel.style(): PriorityStyle = when (this) {
    PriorityLevel.URGENT -> PriorityStyle("🔴", "URGENT", PriorityColors.Urgent, PriorityColors.UrgentContainer)
    PriorityLevel.IMPORTANT -> PriorityStyle("🟠", "IMPORTANT", PriorityColors.Important, PriorityColors.ImportantContainer)
    PriorityLevel.A_TRAITER -> PriorityStyle("🟡", "À TRAITER", PriorityColors.ATraiter, PriorityColors.ATraiterContainer)
    PriorityLevel.INFORMATION -> PriorityStyle("🟢", "INFORMATION", PriorityColors.Information, PriorityColors.InformationContainer)
    PriorityLevel.NORMAL -> PriorityStyle("⚪", "NORMAL", PriorityColors.Normal, PriorityColors.NormalContainer)
}

@Composable
fun PriorityBadge(level: PriorityLevel, score: Int, modifier: Modifier = Modifier) {
    val style = level.style()
    Row(
        modifier = modifier
            .background(style.container, RoundedCornerShape(8.dp))
            .padding(horizontal = 10.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text("${style.emoji} ${style.label}", style = MaterialTheme.typography.labelMedium, color = style.color)
        Text(" · $score/100", style = MaterialTheme.typography.labelSmall, color = style.color)
    }
}
