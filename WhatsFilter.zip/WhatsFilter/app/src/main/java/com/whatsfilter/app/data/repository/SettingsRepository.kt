package com.whatsfilter.app.data.repository

import android.content.Context
import androidx.datastore.preferences.core.edit
import com.whatsfilter.app.data.preferences.SettingsKeys
import com.whatsfilter.app.data.preferences.settingsDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

data class AppSettings(
    val darkMode: String = "system",
    val notificationsEnabled: Boolean = true,
    val urgentOnlyNotifications: Boolean = false,
    val soundEnabled: Boolean = true,
    val vibrationEnabled: Boolean = true,
    val localAIEnabled: Boolean = true,
    val cloudAIEnabled: Boolean = false,
    val language: String = "fr",
    val autoClassification: Boolean = true,
    val privacyMode: Boolean = true,
    val hasCompletedOnboarding: Boolean = false
)

class SettingsRepository(private val context: Context) {

    val settings: Flow<AppSettings> = context.settingsDataStore.data.map { prefs ->
        AppSettings(
            darkMode = prefs[SettingsKeys.DARK_MODE] ?: "system",
            notificationsEnabled = prefs[SettingsKeys.NOTIFICATIONS_ENABLED] ?: true,
            urgentOnlyNotifications = prefs[SettingsKeys.URGENT_ONLY_NOTIFICATIONS] ?: false,
            soundEnabled = prefs[SettingsKeys.SOUND_ENABLED] ?: true,
            vibrationEnabled = prefs[SettingsKeys.VIBRATION_ENABLED] ?: true,
            localAIEnabled = prefs[SettingsKeys.LOCAL_AI_ENABLED] ?: true,
            cloudAIEnabled = prefs[SettingsKeys.CLOUD_AI_ENABLED] ?: false,
            language = prefs[SettingsKeys.LANGUAGE] ?: "fr",
            autoClassification = prefs[SettingsKeys.AUTO_CLASSIFICATION] ?: true,
            privacyMode = prefs[SettingsKeys.PRIVACY_MODE] ?: true,
            hasCompletedOnboarding = prefs[SettingsKeys.ONBOARDING_COMPLETED] ?: false
        )
    }

    suspend fun setDarkMode(mode: String) = context.settingsDataStore.edit { it[SettingsKeys.DARK_MODE] = mode }
    suspend fun setNotificationsEnabled(enabled: Boolean) = context.settingsDataStore.edit { it[SettingsKeys.NOTIFICATIONS_ENABLED] = enabled }
    suspend fun setUrgentOnlyNotifications(enabled: Boolean) = context.settingsDataStore.edit { it[SettingsKeys.URGENT_ONLY_NOTIFICATIONS] = enabled }
    suspend fun setSoundEnabled(enabled: Boolean) = context.settingsDataStore.edit { it[SettingsKeys.SOUND_ENABLED] = enabled }
    suspend fun setVibrationEnabled(enabled: Boolean) = context.settingsDataStore.edit { it[SettingsKeys.VIBRATION_ENABLED] = enabled }
    suspend fun setLocalAIEnabled(enabled: Boolean) = context.settingsDataStore.edit { it[SettingsKeys.LOCAL_AI_ENABLED] = enabled }
    suspend fun setCloudAIEnabled(enabled: Boolean) = context.settingsDataStore.edit { it[SettingsKeys.CLOUD_AI_ENABLED] = enabled }
    suspend fun setLanguage(language: String) = context.settingsDataStore.edit { it[SettingsKeys.LANGUAGE] = language }
    suspend fun setAutoClassification(enabled: Boolean) = context.settingsDataStore.edit { it[SettingsKeys.AUTO_CLASSIFICATION] = enabled }
    suspend fun setPrivacyMode(enabled: Boolean) = context.settingsDataStore.edit { it[SettingsKeys.PRIVACY_MODE] = enabled }
    suspend fun setOnboardingCompleted(completed: Boolean) = context.settingsDataStore.edit { it[SettingsKeys.ONBOARDING_COMPLETED] = completed }
}
