package com.whatsfilter.app.data.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.whatsfilter.app.data.entities.KeywordRuleEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface KeywordRuleDao {

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insert(rule: KeywordRuleEntity): Long

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertAll(rules: List<KeywordRuleEntity>)

    @Update
    suspend fun update(rule: KeywordRuleEntity)

    @Query("SELECT * FROM keyword_rules WHERE enabled = 1")
    fun getAllEnabled(): Flow<List<KeywordRuleEntity>>

    @Query("SELECT * FROM keyword_rules WHERE enabled = 1 AND language = :language")
    suspend fun getEnabledForLanguage(language: String): List<KeywordRuleEntity>

    @Query("SELECT * FROM keyword_rules WHERE categoryId = :categoryId")
    fun getByCategory(categoryId: Long): Flow<List<KeywordRuleEntity>>

    @Query("SELECT COUNT(*) FROM keyword_rules")
    suspend fun count(): Int

    @Query("DELETE FROM keyword_rules WHERE id = :id")
    suspend fun delete(id: Long)
}
