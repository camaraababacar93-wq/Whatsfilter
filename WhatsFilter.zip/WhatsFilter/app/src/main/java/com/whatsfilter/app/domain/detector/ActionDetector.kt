package com.whatsfilter.app.domain.detector

enum class ActionType { CALL, REPLY, SEND_DOCUMENT, MEETING, PAYMENT, REMINDER, OTHER }

data class DetectedAction(val rawText: String, val type: ActionType)

object ActionDetector {

    private val callPhrases = listOf(
        "appelle-moi", "appelle moi", "rappelle-moi", "rappelle moi", "me rappeler",
        "call me", "call back", "اتصل بي"
    )
    private val sendDocPhrases = listOf(
        "envoie-moi", "envoie moi", "envoie le document", "envoie ton cv", "envoie ton document",
        "send me", "send the document"
    )
    private val meetingPhrases = listOf(
        "viens", "passe", "rendez-vous", "rdv", "meeting", "entretien"
    )
    private val reminderPhrases = listOf(
        "n'oublie pas", "noublie pas", "don't forget", "dont forget"
    )
    private val replyPhrases = listOf(
        "réponds-moi", "reponds-moi", "réponds moi", "confirme", "confirmer", "reply", "confirm", "respond"
    )

    fun detect(text: String): DetectedAction? {
        val lower = text.lowercase()

        callPhrases.forEach { if (lower.contains(it.lowercase())) return DetectedAction(it, ActionType.CALL) }
        sendDocPhrases.forEach { if (lower.contains(it)) return DetectedAction(it, ActionType.SEND_DOCUMENT) }
        meetingPhrases.forEach { if (lower.contains(it)) return DetectedAction(it, ActionType.MEETING) }
        reminderPhrases.forEach { if (lower.contains(it)) return DetectedAction(it, ActionType.REMINDER) }
        replyPhrases.forEach { if (lower.contains(it)) return DetectedAction(it, ActionType.REPLY) }

        return null
    }
}
