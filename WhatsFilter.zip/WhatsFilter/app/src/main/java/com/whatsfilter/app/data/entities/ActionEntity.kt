package com.whatsfilter.app.data.entities

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "actions",
    foreignKeys = [
        ForeignKey(
            entity = MessageEntity::class,
            parentColumns = ["id"],
            childColumns = ["messageId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("messageId"), Index("completed")]
)
data class ActionEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,

    val messageId: Long,
    val actionType: String,
    val description: String,
    val dueDate: String? = null,
    val dueTime: String? = null,
    val completed: Boolean = false,

    val createdAt: Long = System.currentTimeMillis()
)
