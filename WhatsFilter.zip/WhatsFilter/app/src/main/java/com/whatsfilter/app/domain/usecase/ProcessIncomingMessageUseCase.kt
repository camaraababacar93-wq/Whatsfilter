package com.whatsfilter.app.domain.usecase

import com.whatsfilter.app.data.entities.ActionEntity
import com.whatsfilter.app.data.entities.MessageEntity
import com.whatsfilter.app.data.repository.ActionRepository
import com.whatsfilter.app.data.repository.KeywordRuleRepository
import com.whatsfilter.app.data.repository.MessageRepository
import com.whatsfilter.app.domain.analyzer.MessageAnalyzer
import com.whatsfilter.app.domain.classifier.CategoryClassifier
import com.whatsfilter.app.domain.classifier.ClassificationResult
import com.whatsfilter.app.domain.detector.ActionType
import com.whatsfilter.app.domain.model.ParsedNotification

class ProcessIncomingMessageUseCase(
    private val messageRepository: MessageRepository,
    private val keywordRuleRepository: KeywordRuleRepository,
    private val actionRepository: ActionRepository,
    private val analyzer: MessageAnalyzer
) {

    suspend fun execute(parsed: ParsedNotification, dedupeKey: String) {
        val alreadyExists = messageRepository.findByDedupeKey(dedupeKey) != null
        if (alreadyExists) return

        val rules = keywordRuleRepository.getEnabledForLanguage("fr") +
            keywordRuleRepository.getEnabledForLanguage("en") +
            keywordRuleRepository.getEnabledForLanguage("ar")

        val result: ClassificationResult = analyzer.analyze(parsed.messageText, rules)
        val categoryId = CategoryClassifier.classify(parsed.messageText, rules)

        val message = MessageEntity(
            conversationId = parsed.conversationId,
            contactName = parsed.contactName,
            messageText = parsed.messageText,
            timestamp = parsed.timestamp,
            sourcePackage = parsed.sourcePackage,
            priorityScore = result.score,
            priorityLevel = result.level.name,
            categoryId = categoryId,
            requiresAction = result.requiresAction,
            detectedDate = result.detectedDate?.rawText,
            detectedTime = result.detectedTime?.rawText,
            detectedAmount = result.detectedAmount?.rawText,
            detectedPhone = null,
            detectedEmail = null,
            keywords = result.matchedKeywords,
            dedupeKey = dedupeKey
        )

        val inserted = messageRepository.insertIfNew(message)
        if (!inserted || !result.requiresAction) return

        val savedMessage = messageRepository.findByDedupeKey(dedupeKey) ?: return

        actionRepository.insert(
            ActionEntity(
                messageId = savedMessage.id,
                actionType = resolveActionType(result).name,
                description = parsed.messageText,
                dueDate = result.detectedDate?.rawText,
                dueTime = result.detectedTime?.rawText
            )
        )
    }

    private fun resolveActionType(result: ClassificationResult): ActionType {
        result.detectedAction?.let { return it.type }
        if (result.isPaymentContext) return ActionType.PAYMENT
        if (result.detectedDate != null && result.detectedTime != null) return ActionType.MEETING
        return ActionType.OTHER
    }
}
