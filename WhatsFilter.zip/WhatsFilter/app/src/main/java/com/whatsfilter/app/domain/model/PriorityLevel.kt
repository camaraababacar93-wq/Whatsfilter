package com.whatsfilter.app.domain.model

enum class PriorityLevel(val minScore: Int, val maxScore: Int) {
    NORMAL(0, 20),
    INFORMATION(21, 40),
    A_TRAITER(41, 60),
    IMPORTANT(61, 80),
    URGENT(81, 100);

    companion object {
        fun fromScore(score: Int): PriorityLevel {
            return entries.firstOrNull { score in it.minScore..it.maxScore } ?: URGENT
        }
    }
}
