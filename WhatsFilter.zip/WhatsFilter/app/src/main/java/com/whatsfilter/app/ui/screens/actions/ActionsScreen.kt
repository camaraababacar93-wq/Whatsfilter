package com.whatsfilter.app.ui.screens.actions

import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.lifecycle.viewmodel.compose.viewModel
import com.whatsfilter.app.ui.components.ActionCard
import com.whatsfilter.app.ui.components.EmptyState
import com.whatsfilter.app.ui.theme.AppSpacing

@Composable
fun ActionsScreen(viewModel: ActionsViewModel = viewModel(factory = ActionsViewModel.Factory)) {
    val state by viewModel.uiState.collectAsState()

    if (state.pending.isEmpty() && state.completed.isEmpty() && !state.isLoading) {
        EmptyState(
            emoji = "🎉",
            title = "Rien à faire",
            subtitle = "Aucune action détectée pour le moment."
        )
        return
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(AppSpacing.md)
    ) {
        item {
            Text(
                "Mes actions",
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(bottom = AppSpacing.md)
            )
        }

        if (state.pending.isNotEmpty()) {
            item {
                Text(
                    "À faire",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.padding(bottom = AppSpacing.sm)
                )
            }
            items(state.pending, key = { it.id }) { action ->
                ActionCard(
                    action = action,
                    onMarkCompleted = { viewModel.markCompleted(action.id) },
                    modifier = Modifier.padding(bottom = AppSpacing.sm)
                )
            }
        }

        if (state.completed.isNotEmpty()) {
            item {
                Text(
                    "Terminées",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.padding(top = AppSpacing.md, bottom = AppSpacing.sm)
                )
            }
            items(state.completed, key = { it.id }) { action ->
                ActionCard(
                    action = action,
                    onMarkCompleted = {},
                    modifier = Modifier.padding(bottom = AppSpacing.sm)
                )
            }
        }
    }
}
