package com.whatsfilter.app.data.preferences

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore

val Context.settingsDataStore by preferencesDataStore(name = "whatsfilter_settings")

object SettingsKeys {
    val DARK_MODE = stringPreferencesKey("dark_mode")
    val NOTIFICATIONS_ENABLED = booleanPreferencesKey("notifications_enabled")
    val URGENT_ONLY_NOTIFICATIONS = booleanPreferencesKey("urgent_only_notifications")
    val SOUND_ENABLED = booleanPreferencesKey("sound_enabled")
    val VIBRATION_ENABLED = booleanPreferencesKey("vibration_enabled")
    val LOCAL_AI_ENABLED = booleanPreferencesKey("local_ai_enabled")
    val CLOUD_AI_ENABLED = booleanPreferencesKey("cloud_ai_enabled")
    val LANGUAGE = stringPreferencesKey("language")
    val AUTO_CLASSIFICATION = booleanPreferencesKey("auto_classification")
    val PRIVACY_MODE = booleanPreferencesKey("privacy_mode")
    val ONBOARDING_COMPLETED = booleanPreferencesKey("onboarding_completed")
}
