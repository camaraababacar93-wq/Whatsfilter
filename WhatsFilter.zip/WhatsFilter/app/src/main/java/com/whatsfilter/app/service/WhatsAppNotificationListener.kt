package com.whatsfilter.app.service

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import com.whatsfilter.app.WhatsFilterApplication
import com.whatsfilter.app.domain.usecase.ProcessIncomingMessageUseCase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

class WhatsAppNotificationListener : NotificationListenerService() {

    private val supportedPackages = setOf("com.whatsapp", "com.whatsapp.w4b")
    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private lateinit var processIncomingMessageUseCase: ProcessIncomingMessageUseCase

    override fun onCreate() {
        super.onCreate()
        val app = application as WhatsFilterApplication
        processIncomingMessageUseCase = app.processIncomingMessageUseCase
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (sbn.packageName !in supportedPackages) return

        val parsed = NotificationParser.parse(sbn) ?: return

        val dedupeKey = DeduplicationManager.buildKey(
            conversationId = parsed.conversationId,
            messageText = parsed.messageText,
            timestamp = parsed.timestamp,
            contactName = parsed.contactName
        )

        if (DeduplicationManager.isRecentDuplicate(dedupeKey)) return

        serviceScope.launch {
            processIncomingMessageUseCase.execute(parsed, dedupeKey)
        }
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification) {
        // Le contenu n'est plus disponible ici (section 25) : rien à faire.
    }
}
