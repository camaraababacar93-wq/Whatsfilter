package com.whatsfilter.app.data.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.whatsfilter.app.data.entities.MessageEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface MessageDao {

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insert(message: MessageEntity): Long

    @Update
    suspend fun update(message: MessageEntity)

    @Query("SELECT * FROM messages WHERE dedupeKey = :dedupeKey LIMIT 1")
    suspend fun findByDedupeKey(dedupeKey: String): MessageEntity?

    @Query("SELECT * FROM messages WHERE isArchived = 0 ORDER BY timestamp DESC")
    fun getAllActive(): Flow<List<MessageEntity>>

    @Query("SELECT * FROM messages WHERE isArchived = 0 AND priorityLevel = :level ORDER BY timestamp DESC")
    fun getByPriorityLevel(level: String): Flow<List<MessageEntity>>

    @Query("SELECT * FROM messages WHERE id = :id")
    fun getById(id: Long): Flow<MessageEntity?>

    @Query("""
        SELECT * FROM messages
        WHERE isArchived = 0 AND (
            messageText LIKE '%' || :query || '%'
            OR contactName LIKE '%' || :query || '%'
        )
        ORDER BY timestamp DESC
    """)
    fun search(query: String): Flow<List<MessageEntity>>

    @Query("SELECT COUNT(*) FROM messages WHERE isArchived = 0 AND priorityLevel = :level")
    fun countByPriorityLevel(level: String): Flow<Int>

    @Query("UPDATE messages SET isRead = 1 WHERE id = :id")
    suspend fun markAsRead(id: Long)

    @Query("UPDATE messages SET isFavorite = :favorite WHERE id = :id")
    suspend fun setFavorite(id: Long, favorite: Boolean)

    @Query("UPDATE messages SET isArchived = 1 WHERE id = :id")
    suspend fun archive(id: Long)

    @Query("UPDATE messages SET categoryId = :categoryId WHERE id = :id")
    suspend fun updateCategory(id: Long, categoryId: Long)

    @Query("DELETE FROM messages")
    suspend fun deleteAll()
}
