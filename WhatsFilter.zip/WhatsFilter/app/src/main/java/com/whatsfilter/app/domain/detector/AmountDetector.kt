package com.whatsfilter.app.domain.detector

data class DetectedAmount(val rawText: String, val value: Double, val currency: String)

object AmountDetector {

    private val amountRegex = Regex(
        """(\d[\d\s]{0,7})\s?(DH|MAD|€|\$|USD|EUR)""",
        RegexOption.IGNORE_CASE
    )

    private val paymentContextWords = listOf(
        "payer", "paiement", "facture", "dois", "devez", "envoyer", "règlement", "reglement",
        "pay", "payment", "invoice", "bill", "due"
    )

    fun detect(text: String): DetectedAmount? {
        val match = amountRegex.find(text) ?: return null
        val rawNumber = match.groupValues[1].replace(" ", "").replace(",", ".")
        val value = rawNumber.toDoubleOrNull() ?: return null
        val currency = match.groupValues[2].uppercase()
        return DetectedAmount(match.value.trim(), value, currency)
    }

    fun isPaymentContext(text: String): Boolean {
        val lower = text.lowercase()
        return paymentContextWords.any { lower.contains(it) }
    }
}
