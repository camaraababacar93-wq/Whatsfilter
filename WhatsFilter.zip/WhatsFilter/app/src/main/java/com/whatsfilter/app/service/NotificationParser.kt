package com.whatsfilter.app.service

import android.app.Notification
import android.service.notification.StatusBarNotification
import androidx.core.app.NotificationCompat
import com.whatsfilter.app.domain.model.ParsedNotification

object NotificationParser {

    fun parse(sbn: StatusBarNotification): ParsedNotification? {
        val notification = sbn.notification
        val extras = notification.extras

        val isGroupSummary = (notification.flags and Notification.FLAG_GROUP_SUMMARY) != 0
        if (isGroupSummary) return null

        val messagingStyle = NotificationCompat.MessagingStyle
            .extractMessagingStyleFromNotification(notification)

        if (messagingStyle != null) {
            val lastMessage = messagingStyle.messages.lastOrNull() ?: return null
            val text = lastMessage.text?.toString()
            if (text.isNullOrBlank()) return null

            val contactName = lastMessage.person?.name?.toString()
                ?: messagingStyle.conversationTitle?.toString()
                ?: extras.getCharSequence(Notification.EXTRA_TITLE)?.toString()
                ?: "Inconnu"

            return ParsedNotification(
                conversationId = buildConversationId(sbn.packageName, contactName),
                contactName = contactName,
                messageText = text,
                timestamp = lastMessage.timestamp.takeIf { it > 0 } ?: sbn.postTime,
                sourcePackage = sbn.packageName
            )
        }

        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString()
        val text = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString()
        if (title.isNullOrBlank() || text.isNullOrBlank()) return null

        return ParsedNotification(
            conversationId = buildConversationId(sbn.packageName, title),
            contactName = title,
            messageText = text,
            timestamp = sbn.postTime,
            sourcePackage = sbn.packageName
        )
    }

    private fun buildConversationId(packageName: String, contactName: String): String {
        return "$packageName:${contactName.trim().lowercase()}"
    }
}
