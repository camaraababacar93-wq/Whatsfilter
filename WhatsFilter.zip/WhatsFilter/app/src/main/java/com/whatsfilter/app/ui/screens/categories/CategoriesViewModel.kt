package com.whatsfilter.app.ui.screens.categories

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.ViewModelProvider.AndroidViewModelFactory.Companion.APPLICATION_KEY
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.whatsfilter.app.WhatsFilterApplication
import com.whatsfilter.app.data.entities.CategoryEntity
import com.whatsfilter.app.data.repository.CategoryRepository
import com.whatsfilter.app.domain.model.Category
import com.whatsfilter.app.domain.model.toDomain
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class CategoriesUiState(
    val categories: List<Category> = emptyList(),
    val isLoading: Boolean = true
)

class CategoriesViewModel(
    private val categoryRepository: CategoryRepository
) : ViewModel() {

    val uiState: StateFlow<CategoriesUiState> = categoryRepository.getAll()
        .map { list -> CategoriesUiState(categories = list.map { it.toDomain() }, isLoading = false) }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = CategoriesUiState()
        )

    fun setEnabled(categoryId: Long, enabled: Boolean) {
        viewModelScope.launch {
            val category = categoryRepository.getById(categoryId) ?: return@launch
            categoryRepository.update(category.copy(enabled = enabled))
        }
    }

    fun deleteCategory(categoryId: Long) {
        viewModelScope.launch { categoryRepository.delete(categoryId) }
    }

    fun saveCategory(id: Long?, name: String, emoji: String, color: String, priorityWeight: Int) {
        viewModelScope.launch {
            if (id == null) {
                categoryRepository.insert(
                    CategoryEntity(name = name, emoji = emoji, color = color, priorityWeight = priorityWeight)
                )
            } else {
                val existing = categoryRepository.getById(id) ?: return@launch
                categoryRepository.update(
                    existing.copy(name = name, emoji = emoji, color = color, priorityWeight = priorityWeight)
                )
            }
        }
    }

    companion object {
        val Factory: ViewModelProvider.Factory = viewModelFactory {
            initializer {
                val app = this[APPLICATION_KEY] as WhatsFilterApplication
                CategoriesViewModel(app.categoryRepository)
            }
        }
    }
}
