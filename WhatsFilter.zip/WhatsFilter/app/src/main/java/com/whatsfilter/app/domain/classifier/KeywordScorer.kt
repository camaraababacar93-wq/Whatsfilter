package com.whatsfilter.app.domain.classifier

import com.whatsfilter.app.data.entities.KeywordRuleEntity

data class KeywordScoreResult(val totalScore: Int, val matchedKeywords: List<String>)

object KeywordScorer {

    private const val MAX_SCORE = 70

    fun score(text: String, rules: List<KeywordRuleEntity>): KeywordScoreResult {
        val lower = text.lowercase()
        val matched = mutableListOf<String>()
        var total = 0

        rules.forEach { rule ->
            if (rule.enabled && lower.contains(rule.keyword.lowercase())) {
                total += rule.weight
                matched.add(rule.keyword)
            }
        }

        return KeywordScoreResult(total.coerceAtMost(MAX_SCORE), matched)
    }
}
