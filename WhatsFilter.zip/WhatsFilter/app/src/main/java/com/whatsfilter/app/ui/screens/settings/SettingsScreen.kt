package com.whatsfilter.app.ui.screens.settings

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Divider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.whatsfilter.app.ui.theme.AppSpacing

@Composable
fun SettingsScreen(viewModel: SettingsViewModel = viewModel(factory = SettingsViewModel.Factory)) {
    val settings by viewModel.settings.collectAsState()
    var showCloudAIConfirm by remember { mutableStateOf(false) }
    var showDeleteConfirm by remember { mutableStateOf(false) }

    if (showCloudAIConfirm) {
        AlertDialog(
            onDismissRequest = { showCloudAIConfirm = false },
            title = { Text("Activer l'IA cloud ?") },
            text = { Text("Certains messages seront envoyés à un service d'intelligence artificielle pour analyse. Voulez-vous continuer ?") },
            confirmButton = {
                TextButton(onClick = {
                    viewModel.setCloudAIEnabled(true)
                    showCloudAIConfirm = false
                }) { Text("Activer") }
            },
            dismissButton = { TextButton(onClick = { showCloudAIConfirm = false }) { Text("Annuler") } }
        )
    }

    if (showDeleteConfirm) {
        AlertDialog(
            onDismissRequest = { showDeleteConfirm = false },
            title = { Text("Supprimer toutes les données ?") },
            text = { Text("Tous les messages et actions enregistrés seront définitivement supprimés. Cette action est irréversible.") },
            confirmButton = {
                TextButton(onClick = {
                    viewModel.clearAllData()
                    showDeleteConfirm = false
                }) { Text("Supprimer") }
            },
            dismissButton = { TextButton(onClick = { showDeleteConfirm = false }) { Text("Annuler") } }
        )
    }

    LazyColumn(modifier = Modifier.fillMaxWidth().padding(AppSpacing.md)) {
        item { SectionTitle("Analyse") }
        item {
            SettingSwitchRow("Classification automatique", settings.autoClassification, viewModel::setAutoClassification)
            SettingSwitchRow("Analyse locale", settings.localAIEnabled, viewModel::setLocalAIEnabled)
            SettingSwitchRow("Analyse IA", settings.cloudAIEnabled) { enabled ->
                if (enabled) showCloudAIConfirm = true else viewModel.setCloudAIEnabled(false)
            }
        }

        item { Divider(modifier = Modifier.padding(vertical = AppSpacing.sm)) }
        item { SectionTitle("Notifications") }
        item {
            SettingSwitchRow("Notifications importantes", settings.notificationsEnabled, viewModel::setNotificationsEnabled)
            SettingSwitchRow("Urgences uniquement", settings.urgentOnlyNotifications, viewModel::setUrgentOnlyNotifications)
            SettingSwitchRow("Son", settings.soundEnabled, viewModel::setSoundEnabled)
            SettingSwitchRow("Vibration", settings.vibrationEnabled, viewModel::setVibrationEnabled)
        }

        item { Divider(modifier = Modifier.padding(vertical = AppSpacing.sm)) }
        item { SectionTitle("Apparence") }
        item {
            listOf("light" to "Mode clair", "dark" to "Mode sombre", "system" to "Système").forEach { (value, label) ->
                RadioRow(label, settings.darkMode == value) { viewModel.setDarkMode(value) }
            }
        }

        item { Divider(modifier = Modifier.padding(vertical = AppSpacing.sm)) }
        item { SectionTitle("Langue") }
        item {
            listOf("fr" to "Français", "en" to "English", "ar" to "العربية").forEach { (value, label) ->
                RadioRow(label, settings.language == value) { viewModel.setLanguage(value) }
            }
        }

        item { Divider(modifier = Modifier.padding(vertical = AppSpacing.sm)) }
        item { SectionTitle("Confidentialité") }
        item {
            Text(
                "Données locales — vos messages restent sur votre appareil tant que l'IA cloud est désactivée.",
                style = MaterialTheme.typography.bodySmall,
                modifier = Modifier.padding(vertical = AppSpacing.sm)
            )
            Text(
                "Supprimer toutes les données",
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.error,
                modifier = Modifier.fillMaxWidth().clickable { showDeleteConfirm = true }.padding(vertical = AppSpacing.sm)
            )
            Text(
                "Exporter mes données (bientôt disponible)",
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.fillMaxWidth().padding(vertical = AppSpacing.sm)
            )
        }

        item { Divider(modifier = Modifier.padding(vertical = AppSpacing.sm)) }
        item { SectionTitle("Démo") }
        item {
            Button(onClick = { viewModel.loadDemoData() }, modifier = Modifier.fillMaxWidth()) {
                Text("Charger des exemples")
            }
            Text(
                "Génère 20 messages fictifs pour tester l'interface sans notification WhatsApp réelle.",
                style = MaterialTheme.typography.bodySmall,
                modifier = Modifier.padding(top = AppSpacing.sm)
            )
        }
    }
}

@Composable
private fun SectionTitle(title: String) {
    Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = AppSpacing.md, bottom = AppSpacing.sm))
}

@Composable
private fun SettingSwitchRow(label: String, checked: Boolean, onToggle: (Boolean) -> Unit) {
    Row(modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, style = MaterialTheme.typography.bodyLarge)
        Switch(checked = checked, onCheckedChange = onToggle)
    }
}

@Composable
private fun RadioRow(label: String, selected: Boolean, onClick: () -> Unit) {
    Row(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        RadioButton(selected = selected, onClick = onClick)
        Text(label, style = MaterialTheme.typography.bodyLarge)
    }
}
