package com.whatsfilter.app.ui.theme

import androidx.compose.ui.graphics.Color

// --- Material 3 : palette de marque WhatsFilter ---

val md_theme_light_primary = Color(0xFF3B5BDB)
val md_theme_light_onPrimary = Color(0xFFFFFFFF)
val md_theme_light_primaryContainer = Color(0xFFDCE1FF)
val md_theme_light_onPrimaryContainer = Color(0xFF00174B)
val md_theme_light_secondary = Color(0xFF5B5F77)
val md_theme_light_onSecondary = Color(0xFFFFFFFF)
val md_theme_light_secondaryContainer = Color(0xFFE0E1F9)
val md_theme_light_onSecondaryContainer = Color(0xFF181C2C)
val md_theme_light_tertiary = Color(0xFF76546E)
val md_theme_light_onTertiary = Color(0xFFFFFFFF)
val md_theme_light_tertiaryContainer = Color(0xFFFFD7F0)
val md_theme_light_onTertiaryContainer = Color(0xFF2D1228)
val md_theme_light_error = Color(0xFFBA1A1A)
val md_theme_light_onError = Color(0xFFFFFFFF)
val md_theme_light_errorContainer = Color(0xFFFFDAD6)
val md_theme_light_onErrorContainer = Color(0xFF410002)
val md_theme_light_background = Color(0xFFFEFBFF)
val md_theme_light_onBackground = Color(0xFF1B1B1F)
val md_theme_light_surface = Color(0xFFFEFBFF)
val md_theme_light_onSurface = Color(0xFF1B1B1F)
val md_theme_light_surfaceVariant = Color(0xFFE3E1EC)
val md_theme_light_onSurfaceVariant = Color(0xFF46464F)
val md_theme_light_outline = Color(0xFF767680)

val md_theme_dark_primary = Color(0xFFB9C3FF)
val md_theme_dark_onPrimary = Color(0xFF00227B)
val md_theme_dark_primaryContainer = Color(0xFF1D3EB4)
val md_theme_dark_onPrimaryContainer = Color(0xFFDCE1FF)
val md_theme_dark_secondary = Color(0xFFC4C5DD)
val md_theme_dark_onSecondary = Color(0xFF2D3142)
val md_theme_dark_secondaryContainer = Color(0xFF434659)
val md_theme_dark_onSecondaryContainer = Color(0xFFE0E1F9)
val md_theme_dark_tertiary = Color(0xFFE6BAD9)
val md_theme_dark_onTertiary = Color(0xFF44273F)
val md_theme_dark_tertiaryContainer = Color(0xFF5D3D56)
val md_theme_dark_onTertiaryContainer = Color(0xFFFFD7F0)
val md_theme_dark_error = Color(0xFFFFB4AB)
val md_theme_dark_onError = Color(0xFF690005)
val md_theme_dark_errorContainer = Color(0xFF93000A)
val md_theme_dark_onErrorContainer = Color(0xFFFFDAD6)
val md_theme_dark_background = Color(0xFF131316)
val md_theme_dark_onBackground = Color(0xFFE4E1E6)
val md_theme_dark_surface = Color(0xFF131316)
val md_theme_dark_onSurface = Color(0xFFE4E1E6)
val md_theme_dark_surfaceVariant = Color(0xFF46464F)
val md_theme_dark_onSurfaceVariant = Color(0xFFC7C5D0)
val md_theme_dark_outline = Color(0xFF90909A)

object PriorityColors {
    val Urgent = Color(0xFFE53935)
    val UrgentContainer = Color(0xFFFFEBEE)

    val Important = Color(0xFFFB8C00)
    val ImportantContainer = Color(0xFFFFF3E0)

    val ATraiter = Color(0xFFF9A825)
    val ATraiterContainer = Color(0xFFFFFDE7)

    val Information = Color(0xFF43A047)
    val InformationContainer = Color(0xFFE8F5E9)

    val Normal = Color(0xFF9E9E9E)
    val NormalContainer = Color(0xFFF5F5F5)
}
