package com.whatsfilter.app.domain.detector

data class DetectedTime(val rawText: String, val hour: Int, val minute: Int)

object TimeDetector {

    private val frHourRegex = Regex("""\b([01]?\d|2[0-3])h([0-5]\d)?\b""")
    private val colonRegex = Regex("""\b([01]?\d|2[0-3]):([0-5]\d)\b""")
    private val enRegex = Regex("""\b([01]?\d)(:([0-5]\d))?\s?(am|pm)\b""", RegexOption.IGNORE_CASE)

    fun detect(text: String): DetectedTime? {
        val lower = text.lowercase()

        frHourRegex.find(lower)?.let { match ->
            val hour = match.groupValues[1].toInt()
            val minute = match.groupValues[2].ifBlank { "0" }.toInt()
            return DetectedTime(match.value, hour, minute)
        }

        colonRegex.find(lower)?.let { match ->
            val hour = match.groupValues[1].toInt()
            val minute = match.groupValues[2].toInt()
            return DetectedTime(match.value, hour, minute)
        }

        enRegex.find(lower)?.let { match ->
            var hour = match.groupValues[1].toInt()
            val minute = match.groupValues[3].ifBlank { "0" }.toInt()
            val meridiem = match.groupValues[4]
            if (meridiem == "pm" && hour < 12) hour += 12
            if (meridiem == "am" && hour == 12) hour = 0
            return DetectedTime(match.value, hour, minute)
        }

        return null
    }
}
