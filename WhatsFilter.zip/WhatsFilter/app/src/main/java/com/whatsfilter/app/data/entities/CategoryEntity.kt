package com.whatsfilter.app.data.entities

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "categories")
data class CategoryEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,

    val name: String,
    val description: String = "",
    val emoji: String,
    val color: String,
    val priorityWeight: Int = 0,
    val enabled: Boolean = true,

    val createdAt: Long = System.currentTimeMillis()
)
