package com.whatsfilter.app.ui.navigation

import androidx.compose.foundation.layout.padding
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.whatsfilter.app.ui.screens.actions.ActionsScreen
import com.whatsfilter.app.ui.screens.categories.CategoriesScreen
import com.whatsfilter.app.ui.screens.dashboard.DashboardScreen
import com.whatsfilter.app.ui.screens.messages.MessagesScreen
import com.whatsfilter.app.ui.screens.settings.SettingsScreen

@Composable
fun WhatsFilterNavGraph() {
    val navController: NavHostController = rememberNavController()

    Scaffold(
        bottomBar = { WhatsFilterBottomBar(navController) }
    ) { padding ->
        NavHost(
            navController = navController,
            startDestination = Screen.Dashboard.route,
            modifier = Modifier.padding(padding)
        ) {
            composable(Screen.Dashboard.route) { DashboardScreen() }
            composable(Screen.Messages.route) { MessagesScreen() }
            composable(Screen.Actions.route) { ActionsScreen() }
            composable(Screen.Categories.route) { CategoriesScreen() }
            composable(Screen.Settings.route) { SettingsScreen() }
        }
    }
}

@Composable
private fun WhatsFilterBottomBar(navController: NavHostController) {
    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = backStackEntry?.destination?.route

    NavigationBar {
        bottomNavItems.forEach { item ->
            NavigationBarItem(
                selected = currentRoute == item.screen.route,
                onClick = {
                    navController.navigate(item.screen.route) {
                        popUpTo(navController.graph.findStartDestination().id) {
                            saveState = true
                        }
                        launchSingleTop = true
                        restoreState = true
                    }
                },
                icon = { Text(item.emoji) },
                label = { Text(item.label) }
            )
        }
    }
}
