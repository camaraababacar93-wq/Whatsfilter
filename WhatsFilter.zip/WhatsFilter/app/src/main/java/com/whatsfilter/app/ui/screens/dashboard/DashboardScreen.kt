package com.whatsfilter.app.ui.screens.dashboard

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.lifecycle.viewmodel.compose.viewModel
import com.whatsfilter.app.ui.components.EmptyState
import com.whatsfilter.app.ui.components.MessageCard
import com.whatsfilter.app.ui.components.StatCard
import com.whatsfilter.app.ui.theme.AppSpacing
import com.whatsfilter.app.ui.theme.PriorityColors

@Composable
fun DashboardScreen(viewModel: DashboardViewModel = viewModel(factory = DashboardViewModel.Factory)) {
    val state by viewModel.uiState.collectAsState()

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(AppSpacing.md)
    ) {
        item {
            Column {
                Text("WhatsFilter", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                Text(
                    "Bonjour 👋 Voici ce qui mérite votre attention.",
                    style = MaterialTheme.typography.bodyMedium,
                    modifier = Modifier.padding(bottom = AppSpacing.md)
                )
            }
        }

        item {
            Row(horizontalArrangement = Arrangement.spacedBy(AppSpacing.sm)) {
                StatCard(
                    emoji = "🔴", count = state.urgentCount, label = "URGENTS",
                    accentColor = PriorityColors.Urgent, containerColor = PriorityColors.UrgentContainer,
                    modifier = Modifier.weight(1f)
                )
                StatCard(
                    emoji = "🟠", count = state.importantCount, label = "IMPORTANTS",
                    accentColor = PriorityColors.Important, containerColor = PriorityColors.ImportantContainer,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        item {
            Row(
                horizontalArrangement = Arrangement.spacedBy(AppSpacing.sm),
                modifier = Modifier.padding(top = AppSpacing.sm)
            ) {
                StatCard(
                    emoji = "🟡", count = state.toHandleCount, label = "À TRAITER",
                    accentColor = PriorityColors.ATraiter, containerColor = PriorityColors.ATraiterContainer,
                    modifier = Modifier.weight(1f)
                )
                StatCard(
                    emoji = "🟢", count = state.informationCount, label = "INFOS",
                    accentColor = PriorityColors.Information, containerColor = PriorityColors.InformationContainer,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        item {
            Text(
                "Messages récents",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier.padding(vertical = AppSpacing.md)
            )
        }

        if (state.recentMessages.isEmpty() && !state.isLoading) {
            item {
                EmptyState(
                    emoji = "🎉",
                    title = "Rien d'urgent",
                    subtitle = "Vous êtes à jour."
                )
            }
        } else {
            items(state.recentMessages, key = { it.id }) { message ->
                MessageCard(
                    message = message,
                    onClick = {},
                    onToggleFavorite = {},
                    onMarkRead = {},
                    modifier = Modifier.padding(bottom = AppSpacing.sm)
                )
            }
        }
    }
}
