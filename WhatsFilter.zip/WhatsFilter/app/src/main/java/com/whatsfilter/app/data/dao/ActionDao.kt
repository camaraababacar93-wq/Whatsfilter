package com.whatsfilter.app.data.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.whatsfilter.app.data.entities.ActionEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface ActionDao {

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insert(action: ActionEntity): Long

    @Update
    suspend fun update(action: ActionEntity)

    @Query("SELECT * FROM actions WHERE completed = 0 ORDER BY dueDate ASC, dueTime ASC")
    fun getPending(): Flow<List<ActionEntity>>

    @Query("SELECT * FROM actions WHERE completed = 1 ORDER BY createdAt DESC")
    fun getCompleted(): Flow<List<ActionEntity>>

    @Query("SELECT * FROM actions WHERE messageId = :messageId")
    fun getByMessage(messageId: Long): Flow<List<ActionEntity>>

    @Query("UPDATE actions SET completed = 1 WHERE id = :id")
    suspend fun markCompleted(id: Long)

    @Query("DELETE FROM actions WHERE id = :id")
    suspend fun delete(id: Long)

    @Query("DELETE FROM actions")
    suspend fun deleteAll()
}
