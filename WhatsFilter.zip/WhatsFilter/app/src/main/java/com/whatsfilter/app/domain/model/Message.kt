package com.whatsfilter.app.domain.model

import com.whatsfilter.app.data.entities.MessageEntity

data class Message(
    val id: Long,
    val conversationId: String,
    val contactName: String,
    val messageText: String,
    val timestamp: Long,
    val priorityScore: Int,
    val priorityLevel: PriorityLevel,
    val categoryId: Long?,
    val requiresAction: Boolean,
    val detectedDate: String?,
    val detectedTime: String?,
    val detectedAmount: String?,
    val keywords: List<String>,
    val isRead: Boolean,
    val isFavorite: Boolean,
    val isArchived: Boolean
)

fun MessageEntity.toDomain(): Message = Message(
    id = id,
    conversationId = conversationId,
    contactName = contactName,
    messageText = messageText,
    timestamp = timestamp,
    priorityScore = priorityScore,
    priorityLevel = PriorityLevel.valueOf(priorityLevel),
    categoryId = categoryId,
    requiresAction = requiresAction,
    detectedDate = detectedDate,
    detectedTime = detectedTime,
    detectedAmount = detectedAmount,
    keywords = keywords,
    isRead = isRead,
    isFavorite = isFavorite,
    isArchived = isArchived
)
