package com.whatsfilter.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import com.whatsfilter.app.ui.AppRoot
import com.whatsfilter.app.ui.theme.WhatsFilterTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            WhatsFilterTheme {
                AppRoot()
            }
        }
    }
}
