package com.whatsfilter.app.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import com.whatsfilter.app.data.dao.ActionDao
import com.whatsfilter.app.data.dao.CategoryDao
import com.whatsfilter.app.data.dao.KeywordRuleDao
import com.whatsfilter.app.data.dao.MessageDao
import com.whatsfilter.app.data.entities.ActionEntity
import com.whatsfilter.app.data.entities.CategoryEntity
import com.whatsfilter.app.data.entities.KeywordRuleEntity
import com.whatsfilter.app.data.entities.MessageEntity

@Database(
    entities = [
        MessageEntity::class,
        CategoryEntity::class,
        KeywordRuleEntity::class,
        ActionEntity::class
    ],
    version = 1,
    exportSchema = true
)
@TypeConverters(Converters::class)
abstract class AppDatabase : RoomDatabase() {

    abstract fun messageDao(): MessageDao
    abstract fun categoryDao(): CategoryDao
    abstract fun keywordRuleDao(): KeywordRuleDao
    abstract fun actionDao(): ActionDao

    companion object {
        private const val DATABASE_NAME = "whatsfilter.db"

        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    DATABASE_NAME
                ).build().also { INSTANCE = it }
            }
        }
    }
}
