package com.whatsfilter.app.domain.model

import com.whatsfilter.app.data.entities.ActionEntity
import com.whatsfilter.app.domain.detector.ActionType

data class ActionItem(
    val id: Long,
    val messageId: Long,
    val actionType: ActionType,
    val description: String,
    val dueDate: String?,
    val dueTime: String?,
    val completed: Boolean
)

fun ActionEntity.toDomain(): ActionItem = ActionItem(
    id = id,
    messageId = messageId,
    actionType = runCatching { ActionType.valueOf(actionType) }.getOrDefault(ActionType.OTHER),
    description = description,
    dueDate = dueDate,
    dueTime = dueTime,
    completed = completed
)
