package com.whatsfilter.app.ui

import android.content.Context
import android.content.Intent
import android.provider.Settings
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.viewmodel.compose.viewModel
import com.whatsfilter.app.service.NotificationAccessChecker
import com.whatsfilter.app.ui.navigation.WhatsFilterNavGraph
import com.whatsfilter.app.ui.screens.onboarding.OnboardingScreen
import com.whatsfilter.app.ui.screens.permission.PermissionScreen
import com.whatsfilter.app.ui.screens.settings.SettingsViewModel

@Composable
fun AppRoot() {
    val context = LocalContext.current
    val settingsViewModel: SettingsViewModel = viewModel(factory = SettingsViewModel.Factory)
    val settings by settingsViewModel.settings.collectAsState()

    var hasNotificationAccess by remember { mutableStateOf(NotificationAccessChecker.isEnabled(context)) }
    val lifecycleOwner = LocalLifecycleOwner.current

    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                hasNotificationAccess = NotificationAccessChecker.isEnabled(context)
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    when {
        !settings.hasCompletedOnboarding -> {
            OnboardingScreen(onFinish = { settingsViewModel.setOnboardingCompleted(true) })
        }
        !hasNotificationAccess -> {
            PermissionScreen(onOpenSettings = { openNotificationAccessSettings(context) })
        }
        else -> {
            WhatsFilterNavGraph()
        }
    }
}

private fun openNotificationAccessSettings(context: Context) {
    context.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
}
