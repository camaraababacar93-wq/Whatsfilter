package com.whatsfilter.app.data.repository

import com.whatsfilter.app.data.dao.CategoryDao
import com.whatsfilter.app.data.entities.CategoryEntity
import kotlinx.coroutines.flow.Flow

class CategoryRepository(private val categoryDao: CategoryDao) {

    fun getAll(): Flow<List<CategoryEntity>> = categoryDao.getAll()
    suspend fun getAllOnce(): List<CategoryEntity> = categoryDao.getAllOnce()
    fun getEnabled(): Flow<List<CategoryEntity>> = categoryDao.getEnabled()
    suspend fun getById(id: Long): CategoryEntity? = categoryDao.getById(id)
    suspend fun count(): Int = categoryDao.count()
    suspend fun insert(category: CategoryEntity): Long = categoryDao.insert(category)
    suspend fun insertAll(categories: List<CategoryEntity>) = categoryDao.insertAll(categories)
    suspend fun update(category: CategoryEntity) = categoryDao.update(category)
    suspend fun delete(id: Long) = categoryDao.delete(id)

    suspend fun seedDefaultCategoriesIfEmpty() {
        if (count() > 0) return
        insertAll(
            listOf(
                CategoryEntity(name = "URGENT", emoji = "\uD83D\uDD34", color = "#E53935", priorityWeight = 100),
                CategoryEntity(name = "IMPORTANT", emoji = "\uD83D\uDFE0", color = "#FB8C00", priorityWeight = 80),
                CategoryEntity(name = "À TRAITER", emoji = "\uD83D\uDFE1", color = "#F9A825", priorityWeight = 60),
                CategoryEntity(name = "INFORMATION", emoji = "\uD83D\uDFE2", color = "#43A047", priorityWeight = 40),
                CategoryEntity(name = "NORMAL", emoji = "\u26AA", color = "#9E9E9E", priorityWeight = 20),
                CategoryEntity(name = "TRAVAIL", emoji = "\uD83D\uDCBC", color = "#3B5BDB", priorityWeight = 0),
                CategoryEntity(name = "ARGENT", emoji = "\uD83D\uDCB0", color = "#2E7D32", priorityWeight = 0),
                CategoryEntity(name = "RENDEZ-VOUS", emoji = "\uD83D\uDCC5", color = "#6A1B9A", priorityWeight = 0),
                CategoryEntity(name = "ADMINISTRATION", emoji = "\uD83D\uDCCB", color = "#455A64", priorityWeight = 0),
                CategoryEntity(name = "DOCUMENTS", emoji = "\uD83D\uDCC4", color = "#00838F", priorityWeight = 0),
                CategoryEntity(name = "FAMILLE", emoji = "\uD83D\uDC6A", color = "#D81B60", priorityWeight = 0),
                CategoryEntity(name = "PERSONNEL", emoji = "\uD83D\uDE42", color = "#5E35B1", priorityWeight = 0),
                CategoryEntity(name = "ACHATS", emoji = "\uD83D\uDED2", color = "#F4511E", priorityWeight = 0)
            )
        )
    }
}
