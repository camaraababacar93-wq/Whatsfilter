package com.whatsfilter.app

import android.app.Application
import com.whatsfilter.app.data.local.AppDatabase
import com.whatsfilter.app.data.repository.ActionRepository
import com.whatsfilter.app.data.repository.CategoryRepository
import com.whatsfilter.app.data.repository.KeywordRuleRepository
import com.whatsfilter.app.data.repository.MessageRepository
import com.whatsfilter.app.data.repository.SettingsRepository
import com.whatsfilter.app.domain.analyzer.LocalMessageAnalyzer
import com.whatsfilter.app.domain.usecase.LoadDemoDataUseCase
import com.whatsfilter.app.domain.usecase.ProcessIncomingMessageUseCase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

class WhatsFilterApplication : Application() {

    private val applicationScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    val database: AppDatabase by lazy { AppDatabase.getInstance(this) }

    val messageRepository: MessageRepository by lazy { MessageRepository(database.messageDao()) }
    val categoryRepository: CategoryRepository by lazy { CategoryRepository(database.categoryDao()) }
    val keywordRuleRepository: KeywordRuleRepository by lazy { KeywordRuleRepository(database.keywordRuleDao()) }
    val actionRepository: ActionRepository by lazy { ActionRepository(database.actionDao()) }
    val settingsRepository: SettingsRepository by lazy { SettingsRepository(this) }

    val processIncomingMessageUseCase: ProcessIncomingMessageUseCase by lazy {
        ProcessIncomingMessageUseCase(
            messageRepository = messageRepository,
            keywordRuleRepository = keywordRuleRepository,
            actionRepository = actionRepository,
            analyzer = LocalMessageAnalyzer()
        )
    }

    val loadDemoDataUseCase: LoadDemoDataUseCase by lazy {
        LoadDemoDataUseCase(processIncomingMessageUseCase)
    }

    override fun onCreate() {
        super.onCreate()

        applicationScope.launch {
            categoryRepository.seedDefaultCategoriesIfEmpty()
            val categoryIdByName = categoryRepository.getAllOnce().associate { it.name to it.id }
            keywordRuleRepository.seedDefaultKeywordRulesIfEmpty(categoryIdByName)
        }
    }
}
