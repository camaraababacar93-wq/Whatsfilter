package com.whatsfilter.app.data.repository

import com.whatsfilter.app.data.dao.KeywordRuleDao
import com.whatsfilter.app.data.entities.KeywordRuleEntity
import kotlinx.coroutines.flow.Flow

class KeywordRuleRepository(private val keywordRuleDao: KeywordRuleDao) {

    fun getAllEnabled(): Flow<List<KeywordRuleEntity>> = keywordRuleDao.getAllEnabled()
    suspend fun getEnabledForLanguage(language: String): List<KeywordRuleEntity> =
        keywordRuleDao.getEnabledForLanguage(language)
    fun getByCategory(categoryId: Long): Flow<List<KeywordRuleEntity>> = keywordRuleDao.getByCategory(categoryId)
    suspend fun count(): Int = keywordRuleDao.count()
    suspend fun insert(rule: KeywordRuleEntity): Long = keywordRuleDao.insert(rule)
    suspend fun update(rule: KeywordRuleEntity) = keywordRuleDao.update(rule)
    suspend fun delete(id: Long) = keywordRuleDao.delete(id)

    suspend fun seedDefaultKeywordRulesIfEmpty(categoryIdByName: Map<String, Long>) {
        if (count() > 0) return

        val urgent = categoryIdByName["URGENT"] ?: return
        val argent = categoryIdByName["ARGENT"] ?: urgent
        val rdv = categoryIdByName["RENDEZ-VOUS"] ?: urgent
        val documents = categoryIdByName["DOCUMENTS"] ?: urgent
        val travail = categoryIdByName["TRAVAIL"] ?: urgent

        val defaultRules = listOf(
            KeywordRuleEntity(keyword = "urgent", categoryId = urgent, weight = 40, language = "fr"),
            KeywordRuleEntity(keyword = "urgence", categoryId = urgent, weight = 40, language = "fr"),
            KeywordRuleEntity(keyword = "immédiatement", categoryId = urgent, weight = 35, language = "fr"),
            KeywordRuleEntity(keyword = "maintenant", categoryId = urgent, weight = 25, language = "fr"),
            KeywordRuleEntity(keyword = "vite", categoryId = urgent, weight = 20, language = "fr"),
            KeywordRuleEntity(keyword = "important", categoryId = urgent, weight = 25, language = "fr"),
            KeywordRuleEntity(keyword = "aujourd'hui", categoryId = urgent, weight = 20, language = "fr"),
            KeywordRuleEntity(keyword = "demain", categoryId = rdv, weight = 15, language = "fr"),
            KeywordRuleEntity(keyword = "avant", categoryId = urgent, weight = 15, language = "fr"),
            KeywordRuleEntity(keyword = "deadline", categoryId = travail, weight = 30, language = "fr"),
            KeywordRuleEntity(keyword = "dernier délai", categoryId = urgent, weight = 35, language = "fr"),
            KeywordRuleEntity(keyword = "rendez-vous", categoryId = rdv, weight = 20, language = "fr"),
            KeywordRuleEntity(keyword = "entretien", categoryId = rdv, weight = 30, language = "fr"),
            KeywordRuleEntity(keyword = "contrat", categoryId = documents, weight = 20, language = "fr"),
            KeywordRuleEntity(keyword = "paiement", categoryId = argent, weight = 25, language = "fr"),
            KeywordRuleEntity(keyword = "facture", categoryId = argent, weight = 20, language = "fr"),
            KeywordRuleEntity(keyword = "document", categoryId = documents, weight = 15, language = "fr"),
            KeywordRuleEntity(keyword = "appel", categoryId = urgent, weight = 15, language = "fr"),

            KeywordRuleEntity(keyword = "urgent", categoryId = urgent, weight = 40, language = "en"),
            KeywordRuleEntity(keyword = "asap", categoryId = urgent, weight = 35, language = "en"),
            KeywordRuleEntity(keyword = "immediately", categoryId = urgent, weight = 35, language = "en"),
            KeywordRuleEntity(keyword = "now", categoryId = urgent, weight = 20, language = "en"),
            KeywordRuleEntity(keyword = "important", categoryId = urgent, weight = 25, language = "en"),
            KeywordRuleEntity(keyword = "deadline", categoryId = travail, weight = 30, language = "en"),
            KeywordRuleEntity(keyword = "meeting", categoryId = rdv, weight = 20, language = "en"),
            KeywordRuleEntity(keyword = "invoice", categoryId = argent, weight = 20, language = "en"),
            KeywordRuleEntity(keyword = "payment", categoryId = argent, weight = 25, language = "en"),

            KeywordRuleEntity(keyword = "عاجل", categoryId = urgent, weight = 40, language = "ar"),
            KeywordRuleEntity(keyword = "فورا", categoryId = urgent, weight = 35, language = "ar"),
            KeywordRuleEntity(keyword = "مهم", categoryId = urgent, weight = 25, language = "ar")
        )

        keywordRuleDao.insertAll(defaultRules)
    }
}
