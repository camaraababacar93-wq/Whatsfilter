package com.whatsfilter.app.domain.detector

object UrgencyDetector {

    private val urgencyEmojis = listOf("🔴", "🚨", "‼️", "⚠️")

    fun score(text: String): Int {
        var score = 0

        val letters = text.filter { it.isLetter() }
        if (letters.isNotEmpty()) {
            val upperRatio = letters.count { it.isUpperCase() }.toDouble() / letters.length
            if (upperRatio > 0.6 && letters.length >= 4) score += 10
        }

        val exclamationCount = text.count { it == '!' }
        if (exclamationCount >= 3) score += 10
        else if (exclamationCount >= 1) score += 5

        if (urgencyEmojis.any { text.contains(it) }) score += 10

        return score.coerceAtMost(20)
    }
}
