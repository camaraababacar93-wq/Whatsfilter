package com.whatsfilter.app.domain.classifier

import com.whatsfilter.app.data.entities.KeywordRuleEntity
import com.whatsfilter.app.domain.detector.ActionDetector
import com.whatsfilter.app.domain.detector.AmountDetector
import com.whatsfilter.app.domain.detector.DateDetector
import com.whatsfilter.app.domain.detector.DetectedAction
import com.whatsfilter.app.domain.detector.DetectedAmount
import com.whatsfilter.app.domain.detector.DetectedDate
import com.whatsfilter.app.domain.detector.DetectedTime
import com.whatsfilter.app.domain.detector.TimeDetector
import com.whatsfilter.app.domain.detector.UrgencyDetector
import com.whatsfilter.app.domain.model.PriorityLevel

data class ClassificationResult(
    val score: Int,
    val level: PriorityLevel,
    val requiresAction: Boolean,
    val matchedKeywords: List<String>,
    val detectedDate: DetectedDate?,
    val detectedTime: DetectedTime?,
    val detectedAmount: DetectedAmount?,
    val detectedAction: DetectedAction?,
    val isPaymentContext: Boolean
)

object PriorityClassifier {

    fun classify(text: String, keywordRules: List<KeywordRuleEntity>): ClassificationResult {
        val keywordResult = KeywordScorer.score(text, keywordRules)

        val detectedAction = ActionDetector.detect(text)
        val actionScore = if (detectedAction != null) 15 else 0

        val detectedDate = DateDetector.detect(text)
        val dateScore = when {
            detectedDate == null -> 0
            detectedDate.isNearTerm -> 15
            else -> 5
        }

        val detectedTime = TimeDetector.detect(text)
        var timeScore = if (detectedTime != null) 10 else 0

        val hasDateAndTime = detectedDate != null && detectedTime != null
        if (hasDateAndTime) timeScore += 10

        val detectedAmount = AmountDetector.detect(text)
        val isPaymentContext = detectedAmount != null && AmountDetector.isPaymentContext(text)
        val moneyScore = if (isPaymentContext) 20 else if (detectedAmount != null) 10 else 0

        val urgencyScore = UrgencyDetector.score(text)

        val contextScore = 0

        val rawScore = keywordResult.totalScore + actionScore + dateScore + timeScore +
            moneyScore + urgencyScore + contextScore

        val finalScore = rawScore.coerceIn(0, 100)
        val level = PriorityLevel.fromScore(finalScore)
        val requiresAction = detectedAction != null || hasDateAndTime

        return ClassificationResult(
            score = finalScore,
            level = level,
            requiresAction = requiresAction,
            matchedKeywords = keywordResult.matchedKeywords,
            detectedDate = detectedDate,
            detectedTime = detectedTime,
            detectedAmount = detectedAmount,
            detectedAction = detectedAction,
            isPaymentContext = isPaymentContext
        )
    }
}
