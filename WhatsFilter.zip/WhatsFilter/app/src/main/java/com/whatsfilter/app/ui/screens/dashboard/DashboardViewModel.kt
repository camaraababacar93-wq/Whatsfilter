package com.whatsfilter.app.ui.screens.dashboard

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.ViewModelProvider.AndroidViewModelFactory.Companion.APPLICATION_KEY
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.whatsfilter.app.WhatsFilterApplication
import com.whatsfilter.app.data.repository.MessageRepository
import com.whatsfilter.app.domain.model.Message
import com.whatsfilter.app.domain.model.PriorityLevel
import com.whatsfilter.app.domain.model.toDomain
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn

data class DashboardUiState(
    val urgentCount: Int = 0,
    val importantCount: Int = 0,
    val toHandleCount: Int = 0,
    val informationCount: Int = 0,
    val recentMessages: List<Message> = emptyList(),
    val isLoading: Boolean = true
)

class DashboardViewModel(
    private val messageRepository: MessageRepository
) : ViewModel() {

    val uiState: StateFlow<DashboardUiState> = combine(
        messageRepository.countByPriorityLevel(PriorityLevel.URGENT.name),
        messageRepository.countByPriorityLevel(PriorityLevel.IMPORTANT.name),
        messageRepository.countByPriorityLevel(PriorityLevel.A_TRAITER.name),
        messageRepository.countByPriorityLevel(PriorityLevel.INFORMATION.name),
        messageRepository.getAllActive()
    ) { urgent, important, toHandle, information, messages ->
        DashboardUiState(
            urgentCount = urgent,
            importantCount = important,
            toHandleCount = toHandle,
            informationCount = information,
            recentMessages = messages.take(10).map { it.toDomain() },
            isLoading = false
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = DashboardUiState()
    )

    companion object {
        val Factory: ViewModelProvider.Factory = viewModelFactory {
            initializer {
                val app = this[APPLICATION_KEY] as WhatsFilterApplication
                DashboardViewModel(app.messageRepository)
            }
        }
    }
}
