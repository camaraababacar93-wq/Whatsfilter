package com.whatsfilter.app.ui.navigation

sealed class Screen(val route: String) {
    object Dashboard : Screen("dashboard")
    object Messages : Screen("messages")
    object Actions : Screen("actions")
    object Categories : Screen("categories")
    object Settings : Screen("settings")
}

data class BottomNavItem(
    val screen: Screen,
    val label: String,
    val emoji: String
)

val bottomNavItems = listOf(
    BottomNavItem(Screen.Dashboard, "Accueil", "🏠"),
    BottomNavItem(Screen.Messages, "Messages", "📥"),
    BottomNavItem(Screen.Actions, "Actions", "⚡"),
    BottomNavItem(Screen.Categories, "Catégories", "🏷️"),
    BottomNavItem(Screen.Settings, "Paramètres", "⚙️")
)
