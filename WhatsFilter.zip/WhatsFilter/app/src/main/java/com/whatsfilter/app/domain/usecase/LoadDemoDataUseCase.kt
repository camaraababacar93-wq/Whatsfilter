package com.whatsfilter.app.domain.usecase

import com.whatsfilter.app.domain.demo.DemoDataGenerator
import com.whatsfilter.app.domain.model.ParsedNotification
import com.whatsfilter.app.service.DeduplicationManager

class LoadDemoDataUseCase(
    private val processIncomingMessageUseCase: ProcessIncomingMessageUseCase
) {
    suspend fun execute() {
        val now = System.currentTimeMillis()

        DemoDataGenerator.generate().forEach { demo ->
            val timestamp = now - demo.minutesAgo * 60_000L
            val conversationId = "demo:${demo.contactName.trim().lowercase()}"

            val parsed = ParsedNotification(
                conversationId = conversationId,
                contactName = demo.contactName,
                messageText = demo.messageText,
                timestamp = timestamp,
                sourcePackage = "demo"
            )

            val dedupeKey = DeduplicationManager.buildKey(
                conversationId = parsed.conversationId,
                messageText = parsed.messageText,
                timestamp = parsed.timestamp,
                contactName = parsed.contactName
            )

            processIncomingMessageUseCase.execute(parsed, dedupeKey)
        }
    }
}
