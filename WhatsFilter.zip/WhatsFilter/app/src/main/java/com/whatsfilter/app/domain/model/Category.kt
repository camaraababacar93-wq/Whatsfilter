package com.whatsfilter.app.domain.model

import com.whatsfilter.app.data.entities.CategoryEntity

data class Category(
    val id: Long,
    val name: String,
    val emoji: String,
    val color: String,
    val priorityWeight: Int,
    val enabled: Boolean
)

fun CategoryEntity.toDomain(): Category = Category(
    id = id,
    name = name,
    emoji = emoji,
    color = color,
    priorityWeight = priorityWeight,
    enabled = enabled
)
