package com.whatsfilter.app.domain.analyzer

import com.whatsfilter.app.data.entities.KeywordRuleEntity
import com.whatsfilter.app.domain.classifier.ClassificationResult
import com.whatsfilter.app.domain.classifier.PriorityClassifier

class AIMessageAnalyzer : MessageAnalyzer {
    override suspend fun analyze(text: String, keywordRules: List<KeywordRuleEntity>): ClassificationResult {
        // Post-MVP : appeler un fournisseur IA cloud ici, après consentement utilisateur.
        return PriorityClassifier.classify(text, keywordRules)
    }
}
