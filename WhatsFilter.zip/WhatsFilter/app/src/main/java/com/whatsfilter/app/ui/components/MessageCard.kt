package com.whatsfilter.app.ui.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.outlined.CheckCircle
import androidx.compose.material.icons.outlined.Star
import androidx.compose.material3.Card
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.whatsfilter.app.domain.model.Message
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

@Composable
fun MessageCard(
    message: Message,
    onClick: () -> Unit,
    onToggleFavorite: () -> Unit,
    onMarkRead: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        onClick = onClick
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = message.contactName,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold
                )
                Text(
                    text = formatMessageTimestamp(message.timestamp),
                    style = MaterialTheme.typography.bodySmall
                )
            }

            Text(
                text = message.messageText,
                style = MaterialTheme.typography.bodyMedium,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.padding(top = 4.dp, bottom = 8.dp)
            )

            PriorityBadge(level = message.priorityLevel, score = message.priorityScore)

            if (message.requiresAction) {
                Text(
                    text = "⚡ Action requise",
                    style = MaterialTheme.typography.labelMedium,
                    modifier = Modifier.padding(top = 6.dp)
                )
            }

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 8.dp),
                horizontalArrangement = Arrangement.End
            ) {
                IconButton(onClick = onMarkRead) {
                    Icon(Icons.Outlined.CheckCircle, contentDescription = "Marquer traité")
                }
                IconButton(onClick = onToggleFavorite) {
                    if (message.isFavorite) {
                        Icon(Icons.Filled.Star, contentDescription = "Retirer des favoris")
                    } else {
                        Icon(Icons.Outlined.Star, contentDescription = "Ajouter aux favoris")
                    }
                }
            }
        }
    }
}

private fun formatMessageTimestamp(timestamp: Long): String {
    val messageCal = Calendar.getInstance().apply { timeInMillis = timestamp }
    val nowCal = Calendar.getInstance()
    val timeFormat = SimpleDateFormat("HH:mm", Locale.FRANCE)

    val isToday = messageCal.get(Calendar.YEAR) == nowCal.get(Calendar.YEAR) &&
        messageCal.get(Calendar.DAY_OF_YEAR) == nowCal.get(Calendar.DAY_OF_YEAR)

    return if (isToday) {
        "Aujourd'hui • ${timeFormat.format(Date(timestamp))}"
    } else {
        val dateFormat = SimpleDateFormat("d MMM", Locale.FRANCE)
        "${dateFormat.format(Date(timestamp))} • ${timeFormat.format(Date(timestamp))}"
    }
}
