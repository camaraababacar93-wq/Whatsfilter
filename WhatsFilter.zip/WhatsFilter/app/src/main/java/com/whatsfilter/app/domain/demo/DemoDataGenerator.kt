package com.whatsfilter.app.domain.demo

data class DemoMessage(val contactName: String, val messageText: String, val minutesAgo: Int)

object DemoDataGenerator {

    fun generate(): List<DemoMessage> = listOf(
        DemoMessage("Mamadou", "URGENT ! Appelle-moi immédiatement concernant ton dossier.", 5),
        DemoMessage("Sophie RH", "Ton entretien est demain à 9h, n'oublie pas ton CV.", 20),
        DemoMessage("Karim", "Peux-tu m'envoyer ton CV avant ce soir ?", 35),
        DemoMessage("Maman", "Salut, ça va ? On se voit ce week-end ?", 50),
        DemoMessage("Service Client Orange", "Votre facture de 450 DH est disponible.", 70),
        DemoMessage("Yassine", "Tu peux me rappeler dès que possible ?", 90),
        DemoMessage("Agence Immobilière", "Rendez-vous confirmé lundi à 14h30 pour la visite.", 120),
        DemoMessage("Julie", "Deadline du rapport : demain avant midi, dernier délai.", 150),
        DemoMessage("Ahmed", "Merci pour hier, c'était top !", 180),
        DemoMessage("Banque Populaire", "Paiement de 1 200 DH prélevé sur votre compte.", 200),
        DemoMessage("Groupe Foot du dimanche", "Qui vient au match samedi ?", 220),
        DemoMessage("Sarah", "Confirme-moi ta présence pour l'anniversaire please", 260),
        DemoMessage("Client Awa", "Bonjour, le contrat est-il prêt ? J'en ai besoin avant vendredi.", 300),
        DemoMessage("Papa", "N'oublie pas d'appeler le médecin pour le rendez-vous.", 340),
        DemoMessage("Notaire Maître Idrissi", "Merci de venir signer les documents jeudi à 10h.", 380),
        DemoMessage("Livraison Glovo", "Votre commande arrive dans 10 minutes.", 400),
        DemoMessage("Chef de projet", "Meeting tomorrow at 10am, don't be late.", 430),
        DemoMessage("Voisin Hassan", "Tu as vu le match hier ?", 460),
        DemoMessage("École des enfants", "Réunion parents-professeurs mardi à 18h, présence importante.", 500),
        DemoMessage("Inconnu", "اتصل بي فوراً بخصوص الطلب", 520)
    )
}
