package com.whatsfilter.app.data.repository

import com.whatsfilter.app.data.dao.MessageDao
import com.whatsfilter.app.data.entities.MessageEntity
import kotlinx.coroutines.flow.Flow

class MessageRepository(private val messageDao: MessageDao) {

    fun getAllActive(): Flow<List<MessageEntity>> = messageDao.getAllActive()
    fun getByPriorityLevel(level: String): Flow<List<MessageEntity>> = messageDao.getByPriorityLevel(level)
    fun getById(id: Long): Flow<MessageEntity?> = messageDao.getById(id)
    fun search(query: String): Flow<List<MessageEntity>> = messageDao.search(query)
    fun countByPriorityLevel(level: String): Flow<Int> = messageDao.countByPriorityLevel(level)
    suspend fun findByDedupeKey(dedupeKey: String): MessageEntity? = messageDao.findByDedupeKey(dedupeKey)

    suspend fun insertIfNew(message: MessageEntity): Boolean {
        val existing = messageDao.findByDedupeKey(message.dedupeKey)
        if (existing != null) return false
        messageDao.insert(message)
        return true
    }

    suspend fun update(message: MessageEntity) = messageDao.update(message)
    suspend fun markAsRead(id: Long) = messageDao.markAsRead(id)
    suspend fun setFavorite(id: Long, favorite: Boolean) = messageDao.setFavorite(id, favorite)
    suspend fun archive(id: Long) = messageDao.archive(id)
    suspend fun updateCategory(id: Long, categoryId: Long) = messageDao.updateCategory(id, categoryId)
    suspend fun deleteAll() = messageDao.deleteAll()
}
