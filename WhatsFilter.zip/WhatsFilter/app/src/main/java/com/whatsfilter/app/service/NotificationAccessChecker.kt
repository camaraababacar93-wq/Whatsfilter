package com.whatsfilter.app.service

import android.content.Context
import androidx.core.app.NotificationManagerCompat

object NotificationAccessChecker {
    fun isEnabled(context: Context): Boolean {
        val enabledPackages = NotificationManagerCompat.getEnabledListenerPackages(context)
        return context.packageName in enabledPackages
    }
}
