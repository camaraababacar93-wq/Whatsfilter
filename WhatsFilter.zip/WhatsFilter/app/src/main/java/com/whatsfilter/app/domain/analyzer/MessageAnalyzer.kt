package com.whatsfilter.app.domain.analyzer

import com.whatsfilter.app.data.entities.KeywordRuleEntity
import com.whatsfilter.app.domain.classifier.ClassificationResult

interface MessageAnalyzer {
    suspend fun analyze(text: String, keywordRules: List<KeywordRuleEntity>): ClassificationResult
}
