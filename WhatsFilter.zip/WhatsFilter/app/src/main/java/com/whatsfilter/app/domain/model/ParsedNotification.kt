package com.whatsfilter.app.domain.model

data class ParsedNotification(
    val conversationId: String,
    val contactName: String,
    val messageText: String,
    val timestamp: Long,
    val sourcePackage: String
)
