package com.whatsfilter.app.ui.screens.messages

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import com.whatsfilter.app.ui.components.EmptyState
import com.whatsfilter.app.ui.components.MessageCard
import com.whatsfilter.app.ui.components.SearchBar
import com.whatsfilter.app.ui.components.WhatsFilterChip
import com.whatsfilter.app.ui.theme.AppSpacing

@Composable
fun MessagesScreen(viewModel: MessagesViewModel = viewModel(factory = MessagesViewModel.Factory)) {
    val state by viewModel.uiState.collectAsState()

    Column(modifier = Modifier.fillMaxSize()) {
        SearchBar(
            query = state.searchQuery,
            onQueryChange = viewModel::setSearchQuery,
            modifier = Modifier.padding(AppSpacing.md)
        )

        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(AppSpacing.sm),
            contentPadding = PaddingValues(horizontal = AppSpacing.md)
        ) {
            items(filterOptions) { option ->
                WhatsFilterChip(
                    label = option.second,
                    selected = state.filter == option.first,
                    onClick = { viewModel.setFilter(option.first) }
                )
            }
        }

        if (state.messages.isEmpty() && !state.isLoading) {
            EmptyState(
                emoji = "📭",
                title = "Aucun message",
                subtitle = "Les messages WhatsApp détectés apparaîtront ici."
            )
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(AppSpacing.md)
            ) {
                items(state.messages, key = { it.id }) { message ->
                    MessageCard(
                        message = message,
                        onClick = { viewModel.markAsRead(message.id) },
                        onToggleFavorite = { viewModel.toggleFavorite(message.id, message.isFavorite) },
                        onMarkRead = { viewModel.markAsRead(message.id) },
                        modifier = Modifier.padding(bottom = AppSpacing.sm)
                    )
                }
            }
        }
    }
}

private val filterOptions = listOf(
    MessageFilter.ALL to "Tous",
    MessageFilter.URGENT to "Urgents",
    MessageFilter.IMPORTANT to "Importants",
    MessageFilter.TO_HANDLE to "À traiter",
    MessageFilter.INFORMATION to "Informations",
    MessageFilter.NORMAL to "Normaux"
)
