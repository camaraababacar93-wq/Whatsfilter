package com.whatsfilter.app.ui.screens.actions

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.ViewModelProvider.AndroidViewModelFactory.Companion.APPLICATION_KEY
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.whatsfilter.app.WhatsFilterApplication
import com.whatsfilter.app.data.repository.ActionRepository
import com.whatsfilter.app.domain.model.ActionItem
import com.whatsfilter.app.domain.model.toDomain
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class ActionsUiState(
    val pending: List<ActionItem> = emptyList(),
    val completed: List<ActionItem> = emptyList(),
    val isLoading: Boolean = true
)

class ActionsViewModel(
    private val actionRepository: ActionRepository
) : ViewModel() {

    val uiState: StateFlow<ActionsUiState> = combine(
        actionRepository.getPending(),
        actionRepository.getCompleted()
    ) { pending, completed ->
        ActionsUiState(
            pending = pending.map { it.toDomain() },
            completed = completed.map { it.toDomain() },
            isLoading = false
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = ActionsUiState()
    )

    fun markCompleted(actionId: Long) {
        viewModelScope.launch { actionRepository.markCompleted(actionId) }
    }

    companion object {
        val Factory: ViewModelProvider.Factory = viewModelFactory {
            initializer {
                val app = this[APPLICATION_KEY] as WhatsFilterApplication
                ActionsViewModel(app.actionRepository)
            }
        }
    }
}
