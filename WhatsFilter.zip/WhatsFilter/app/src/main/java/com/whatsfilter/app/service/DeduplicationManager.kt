package com.whatsfilter.app.service

import java.security.MessageDigest

object DeduplicationManager {

    private const val CACHE_MAX_SIZE = 200
    private val recentKeys = object : LinkedHashMap<String, Boolean>(16, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, Boolean>?): Boolean {
            return size > CACHE_MAX_SIZE
        }
    }

    fun buildKey(conversationId: String, messageText: String, timestamp: Long, contactName: String): String {
        val raw = "$conversationId|$messageText|$timestamp|$contactName"
        val digest = MessageDigest.getInstance("SHA-256").digest(raw.toByteArray())
        return digest.joinToString("") { "%02x".format(it) }
    }

    @Synchronized
    fun isRecentDuplicate(key: String): Boolean {
        if (recentKeys.containsKey(key)) return true
        recentKeys[key] = true
        return false
    }
}
