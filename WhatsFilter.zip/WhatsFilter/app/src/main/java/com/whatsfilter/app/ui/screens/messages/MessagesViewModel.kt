package com.whatsfilter.app.ui.screens.messages

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.ViewModelProvider.AndroidViewModelFactory.Companion.APPLICATION_KEY
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.whatsfilter.app.WhatsFilterApplication
import com.whatsfilter.app.data.repository.MessageRepository
import com.whatsfilter.app.domain.model.Message
import com.whatsfilter.app.domain.model.PriorityLevel
import com.whatsfilter.app.domain.model.toDomain
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

enum class MessageFilter { ALL, URGENT, IMPORTANT, TO_HANDLE, INFORMATION, NORMAL }

data class MessagesUiState(
    val messages: List<Message> = emptyList(),
    val filter: MessageFilter = MessageFilter.ALL,
    val searchQuery: String = "",
    val isLoading: Boolean = true
)

@OptIn(ExperimentalCoroutinesApi::class)
class MessagesViewModel(
    private val messageRepository: MessageRepository
) : ViewModel() {

    private val filter = MutableStateFlow(MessageFilter.ALL)
    private val searchQuery = MutableStateFlow("")

    val uiState: StateFlow<MessagesUiState> = combine(filter, searchQuery) { f, q -> f to q }
        .flatMapLatest { (f, q) ->
            val source = if (q.isBlank()) {
                when (f) {
                    MessageFilter.ALL -> messageRepository.getAllActive()
                    MessageFilter.URGENT -> messageRepository.getByPriorityLevel(PriorityLevel.URGENT.name)
                    MessageFilter.IMPORTANT -> messageRepository.getByPriorityLevel(PriorityLevel.IMPORTANT.name)
                    MessageFilter.TO_HANDLE -> messageRepository.getByPriorityLevel(PriorityLevel.A_TRAITER.name)
                    MessageFilter.INFORMATION -> messageRepository.getByPriorityLevel(PriorityLevel.INFORMATION.name)
                    MessageFilter.NORMAL -> messageRepository.getByPriorityLevel(PriorityLevel.NORMAL.name)
                }
            } else {
                messageRepository.search(q)
            }
            source.map { list ->
                MessagesUiState(
                    messages = list.map { entity -> entity.toDomain() },
                    filter = f,
                    searchQuery = q,
                    isLoading = false
                )
            }
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = MessagesUiState()
        )

    fun setFilter(newFilter: MessageFilter) = filter.update { newFilter }
    fun setSearchQuery(query: String) = searchQuery.update { query }

    fun toggleFavorite(messageId: Long, current: Boolean) {
        viewModelScope.launch { messageRepository.setFavorite(messageId, !current) }
    }

    fun markAsRead(messageId: Long) {
        viewModelScope.launch { messageRepository.markAsRead(messageId) }
    }

    companion object {
        val Factory: ViewModelProvider.Factory = viewModelFactory {
            initializer {
                val app = this[APPLICATION_KEY] as WhatsFilterApplication
                MessagesViewModel(app.messageRepository)
            }
        }
    }
}
