package com.whatsfilter.app.data.entities

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "messages",
    foreignKeys = [
        ForeignKey(
            entity = CategoryEntity::class,
            parentColumns = ["id"],
            childColumns = ["categoryId"],
            onDelete = ForeignKey.SET_NULL
        )
    ],
    indices = [
        Index("categoryId"),
        Index("conversationId"),
        Index("isArchived"),
        Index(value = ["dedupeKey"], unique = true)
    ]
)
data class MessageEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,

    val conversationId: String,
    val contactName: String,
    val messageText: String,
    val timestamp: Long,
    val sourcePackage: String,

    val priorityScore: Int,
    val priorityLevel: String,
    val categoryId: Long?,
    val requiresAction: Boolean,

    val detectedDate: String? = null,
    val detectedTime: String? = null,
    val detectedAmount: String? = null,
    val detectedPhone: String? = null,
    val detectedEmail: String? = null,
    val keywords: List<String> = emptyList(),

    val isRead: Boolean = false,
    val isProcessed: Boolean = true,
    val isFavorite: Boolean = false,
    val isArchived: Boolean = false,

    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),

    val dedupeKey: String
)
