package com.whatsfilter.app.domain.detector

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Test

class TimeDetectorTest {

    @Test
    fun `detects french hour format with minutes`() {
        val result = TimeDetector.detect("Rendez-vous à 09h30")
        assertNotNull(result)
        assertEquals(9, result!!.hour)
        assertEquals(30, result.minute)
    }

    @Test
    fun `detects french hour format without minutes`() {
        val result = TimeDetector.detect("Entretien lundi à 9h")
        assertNotNull(result)
        assertEquals(9, result!!.hour)
        assertEquals(0, result.minute)
    }

    @Test
    fun `detects colon format`() {
        val result = TimeDetector.detect("On se voit à 14:30")
        assertNotNull(result)
        assertEquals(14, result!!.hour)
        assertEquals(30, result.minute)
    }

    @Test
    fun `detects english am pm format`() {
        val result = TimeDetector.detect("Meeting tomorrow at 10am")
        assertNotNull(result)
        assertEquals(10, result!!.hour)
    }

    @Test
    fun `returns null when no time present`() {
        val result = TimeDetector.detect("Salut ça va ?")
        assertNull(result)
    }
}
