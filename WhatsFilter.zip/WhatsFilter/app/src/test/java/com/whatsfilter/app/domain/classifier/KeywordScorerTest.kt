package com.whatsfilter.app.domain.classifier

import com.whatsfilter.app.data.entities.KeywordRuleEntity
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class KeywordScorerTest {

    private val rules = listOf(
        KeywordRuleEntity(id = 1, keyword = "urgent", categoryId = 1, weight = 40, language = "fr"),
        KeywordRuleEntity(id = 2, keyword = "facture", categoryId = 2, weight = 20, language = "fr"),
        KeywordRuleEntity(id = 3, keyword = "vacances", categoryId = 3, weight = 10, language = "fr", enabled = false)
    )

    @Test
    fun `sums weights of matched keywords`() {
        val result = KeywordScorer.score("URGENT ! Facture à payer", rules)
        assertEquals(60, result.totalScore)
        assertEquals(2, result.matchedKeywords.size)
    }

    @Test
    fun `ignores disabled keywords`() {
        val result = KeywordScorer.score("On part en vacances", rules)
        assertTrue(result.matchedKeywords.isEmpty())
    }

    @Test
    fun `returns zero for unrelated text`() {
        val result = KeywordScorer.score("Salut ça va ?", rules)
        assertEquals(0, result.totalScore)
    }
}
