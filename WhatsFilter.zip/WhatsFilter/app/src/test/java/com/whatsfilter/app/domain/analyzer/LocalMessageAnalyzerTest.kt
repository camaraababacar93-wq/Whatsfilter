package com.whatsfilter.app.domain.analyzer

import com.whatsfilter.app.domain.model.PriorityLevel
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Test

class LocalMessageAnalyzerTest {

    private val analyzer = LocalMessageAnalyzer()

    @Test
    fun `delegates to PriorityClassifier and returns a result`() = runTest {
        val result = analyzer.analyze("Salut ça va ?", emptyList())
        assertEquals(PriorityLevel.NORMAL, result.level)
    }
}
