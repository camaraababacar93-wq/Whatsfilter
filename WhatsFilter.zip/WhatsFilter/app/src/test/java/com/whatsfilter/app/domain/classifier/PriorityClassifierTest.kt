package com.whatsfilter.app.domain.classifier

import com.whatsfilter.app.data.entities.KeywordRuleEntity
import com.whatsfilter.app.domain.model.PriorityLevel
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class PriorityClassifierTest {

    private val rules = listOf(
        KeywordRuleEntity(id = 1, keyword = "urgent", categoryId = 1, weight = 40, language = "fr"),
        KeywordRuleEntity(id = 2, keyword = "immédiatement", categoryId = 1, weight = 35, language = "fr"),
        KeywordRuleEntity(id = 3, keyword = "entretien", categoryId = 2, weight = 30, language = "fr"),
        KeywordRuleEntity(id = 4, keyword = "facture", categoryId = 3, weight = 20, language = "fr"),
        KeywordRuleEntity(id = 5, keyword = "meeting", categoryId = 2, weight = 20, language = "en")
    )

    @Test
    fun `casual message is classified as low priority`() {
        val result = PriorityClassifier.classify("Salut, ça va ?", rules)
        assertTrue(result.score <= 20)
        assertEquals(PriorityLevel.NORMAL, result.level)
        assertEquals(false, result.requiresAction)
    }

    @Test
    fun `urgent call request scores high`() {
        val result = PriorityClassifier.classify("URGENT ! Appelle-moi immédiatement.", rules)
        assertTrue("score attendu élevé, obtenu ${result.score}", result.score >= 61)
        assertEquals(true, result.requiresAction)
    }

    @Test
    fun `appointment with date and time requires action`() {
        val result = PriorityClassifier.classify("Ton entretien est demain à 9h.", rules)
        assertEquals(true, result.requiresAction)
        assertTrue(result.detectedDate != null)
        assertTrue(result.detectedTime != null)
    }

    @Test
    fun `document request is detected as an action`() {
        val result = PriorityClassifier.classify("Peux-tu m'envoyer ton CV ?", rules)
        assertEquals(true, result.requiresAction)
    }

    @Test
    fun `invoice message is flagged as payment context`() {
        val result = PriorityClassifier.classify("Facture de 500 DH à payer", rules)
        assertEquals(true, result.isPaymentContext)
    }

    @Test
    fun `english meeting message is detected`() {
        val result = PriorityClassifier.classify("Meeting tomorrow at 10am", rules)
        assertEquals(true, result.requiresAction)
        assertTrue(result.detectedDate != null)
    }

    @Test
    fun `arabic urgent call message triggers action`() {
        val result = PriorityClassifier.classify("اتصل بي فوراً", rules)
        assertEquals(true, result.requiresAction)
    }
}
