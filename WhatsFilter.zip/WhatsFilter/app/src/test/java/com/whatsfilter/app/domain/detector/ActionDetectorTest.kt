package com.whatsfilter.app.domain.detector

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Test

class ActionDetectorTest {

    @Test
    fun `detects call action`() {
        val result = ActionDetector.detect("URGENT appelle-moi")
        assertNotNull(result)
        assertEquals(ActionType.CALL, result!!.type)
    }

    @Test
    fun `detects send document action`() {
        val result = ActionDetector.detect("Envoie-moi le document")
        assertNotNull(result)
        assertEquals(ActionType.SEND_DOCUMENT, result!!.type)
    }

    @Test
    fun `detects meeting action`() {
        val result = ActionDetector.detect("Rendez-vous demain à 10h")
        assertNotNull(result)
        assertEquals(ActionType.MEETING, result!!.type)
    }

    @Test
    fun `returns null for casual message`() {
        val result = ActionDetector.detect("Salut ça va ?")
        assertNull(result)
    }

    @Test
    fun `detects call request phrased as a question`() {
        val result = ActionDetector.detect("Tu peux me rappeler ?")
        assertNotNull(result)
        assertEquals(ActionType.CALL, result!!.type)
    }

    @Test
    fun `detects arabic call request`() {
        val result = ActionDetector.detect("اتصل بي فوراً")
        assertNotNull(result)
        assertEquals(ActionType.CALL, result!!.type)
    }
}
