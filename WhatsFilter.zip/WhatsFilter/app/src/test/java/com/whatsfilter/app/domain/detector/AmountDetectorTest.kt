package com.whatsfilter.app.domain.detector

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class AmountDetectorTest {

    @Test
    fun `detects amount with DH currency`() {
        val result = AmountDetector.detect("Facture de 500 DH à payer")
        assertNotNull(result)
        assertEquals(500.0, result!!.value, 0.01)
        assertEquals("DH", result.currency)
    }

    @Test
    fun `detects amount with euro symbol`() {
        val result = AmountDetector.detect("Le total est de 100€")
        assertNotNull(result)
        assertEquals(100.0, result!!.value, 0.01)
    }

    @Test
    fun `detects amount with thousand separator`() {
        val result = AmountDetector.detect("Montant : 1 200 DH")
        assertNotNull(result)
        assertEquals(1200.0, result!!.value, 0.01)
    }

    @Test
    fun `recognizes payment context`() {
        assertTrue(AmountDetector.isPaymentContext("Facture de 500 DH à payer"))
    }

    @Test
    fun `returns null when no amount present`() {
        val result = AmountDetector.detect("Salut ça va ?")
        assertNull(result)
    }
}
