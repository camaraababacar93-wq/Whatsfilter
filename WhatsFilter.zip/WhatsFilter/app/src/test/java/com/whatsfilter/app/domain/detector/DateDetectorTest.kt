package com.whatsfilter.app.domain.detector

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class DateDetectorTest {

    @Test
    fun `detects aujourd'hui as near term`() {
        val result = DateDetector.detect("Il faut finir ça aujourd'hui")
        assertNotNull(result)
        assertTrue(result!!.isNearTerm)
    }

    @Test
    fun `detects demain as near term`() {
        val result = DateDetector.detect("Rendez-vous demain à 10h")
        assertNotNull(result)
        assertTrue(result!!.isNearTerm)
    }

    @Test
    fun `detects weekday as non near term`() {
        val result = DateDetector.detect("Entretien lundi à 9h")
        assertNotNull(result)
        assertEquals(false, result!!.isNearTerm)
    }

    @Test
    fun `detects numeric date`() {
        val result = DateDetector.detect("On se voit le 25/09/2026")
        assertNotNull(result)
    }

    @Test
    fun `detects english tomorrow`() {
        val result = DateDetector.detect("Meeting tomorrow at 10am")
        assertNotNull(result)
        assertTrue(result!!.isNearTerm)
    }

    @Test
    fun `returns null when no date present`() {
        val result = DateDetector.detect("Salut ça va ?")
        assertNull(result)
    }
}
