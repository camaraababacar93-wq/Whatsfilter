# WhatsFilter

Boîte de réception intelligente pour WhatsApp : détecte, analyse et classe
automatiquement les notifications par niveau d'importance (URGENT, IMPORTANT,
À TRAITER, INFORMATION, NORMAL), entièrement en local (Kotlin + Jetpack
Compose + Room + NotificationListenerService).

## Ouvrir le projet

1. Android Studio (récent) → **File → Open** → sélectionner ce dossier.
2. Laisser Gradle synchroniser (les dépendances se téléchargent au premier
   sync, connexion internet nécessaire).
3. **Run ▶** sur un émulateur ou un appareil réel (Android 8.0 / API 26 minimum).
   WhatsApp n'existant pas sur l'émulateur, un appareil réel est recommandé
   pour tester la détection de vraies notifications — sinon, utilise le mode
   démo (voir plus bas).

## Premier lancement

1. Onboarding (3 écrans) → "Commencer".
2. Écran de permission → "Autoriser l'accès aux notifications" → ouvre les
   réglages Android → active WhatsFilter dans la liste → reviens en arrière.
3. L'app bascule automatiquement sur le Dashboard.

## Tester sans notification WhatsApp réelle

**Paramètres → section Démo → "Charger des exemples"** génère 20 messages
fictifs couvrant tous les niveaux de priorité et catégories.

## Tests unitaires

```
./gradlew test
```

7 classes de test couvrent les détecteurs (date/heure/montant/action), le
scoring par mots-clés, le classifieur de priorité et l'analyseur local.

## Ce qui est volontairement hors MVP

- `AIMessageAnalyzer` : stub non connecté à un fournisseur IA (toggle UI
  fonctionnel, aucun appel réseau).
- Rappels : stockés en base et visibles dans "Actions", pas encore de vraie
  alarme système.
- Export de données : bouton présent, non implémenté.
- Icônes de lancement par défaut (Android Studio).
